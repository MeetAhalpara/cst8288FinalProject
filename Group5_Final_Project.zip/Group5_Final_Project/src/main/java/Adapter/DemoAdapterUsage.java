package Adapter;

import TransferObject.GpsTrackingDTO;
import java.util.Date;

/**
 * DemoAdapterUsage is a test class that demonstrates how to use
 * the Adapter Pattern to convert data from an external GPS format
 * into the internal GpsTrackingDTO format used by the system.
 * 
 * Author: Meet Ahalpara
 */
public class DemoAdapterUsage {

    /**
     * The main method demonstrates how the GpsDataAdapter converts
     * an ExternalGpsData object into a GpsTrackingDTO.
     * 
     * This simulates adapting third-party GPS data into your system's format.
     */
    public static void main(String[] args) {
        // Simulated external GPS data
        ExternalGpsData externalData = new ExternalGpsData("device_123", "43.651070,-79.347015", new Date());

        // Convert to internal DTO using the Adapter
        GpsTrackingDTO dto = GpsDataAdapter.convertToDTO(externalData, 101, 202);

        // Output the converted DTO
        System.out.println("Converted DTO: " + dto);
    }
}
