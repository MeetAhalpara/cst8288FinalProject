package Adapter;

import java.util.Date;

/**
 * ExternalGpsData represents GPS tracking data from an external source.
 * 
 * It contains the device ID, location in string format (latitude,longitude),
 * and the date and time when the data was recorded.
 * 
 * This class is typically used when adapting third-party GPS input into
 * your internal system format using the Adapter Pattern.
 * 
 * Author: Meet Ahalpara
 */
public class ExternalGpsData {
    private String deviceId;
    private String location; // e.g., "43.651070,-79.347015"
    private Date recordedAt;

    /**
     * Constructor to create a new ExternalGpsData object.
     * 
     * @param deviceId   the ID of the GPS device
     * @param location   the GPS location in "latitude,longitude" format
     * @param recordedAt the date and time the data was recorded
     */
    public ExternalGpsData(String deviceId, String location, Date recordedAt) {
        this.deviceId = deviceId;
        this.location = location;
        this.recordedAt = recordedAt;
    }

    /**
     * Returns the device ID of the GPS unit.
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * Returns the location string (latitude and longitude).
     */
    public String getLocation() {
        return location;
    }

    /**
     * Returns the date and time when the GPS data was recorded.
     */
    public Date getRecordedAt() {
        return recordedAt;
    }
}
