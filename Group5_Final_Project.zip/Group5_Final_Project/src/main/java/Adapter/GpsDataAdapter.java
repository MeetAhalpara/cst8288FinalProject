package Adapter;

import TransferObject.GpsTrackingDTO;
import java.sql.Timestamp;

/**
 * GpsDataAdapter is used to convert external GPS data into the internal
 * GpsTrackingDTO format used by the system.
 * 
 * This class implements the Adapter Design Pattern to bridge the gap
 * between third-party GPS data and your system's tracking structure.
 * 
 * Author: Meet Ahalpara
 */
public class GpsDataAdapter {

    /**
     * Converts ExternalGpsData into a GpsTrackingDTO object.
     * 
     * It extracts the latitude and longitude from the location string,
     * generates a random GPS ID, and converts the timestamp into the required format.
     * 
     * @param externalData the external GPS data to convert
     * @param vehicleId    the vehicle ID associated with the data
     * @param routeId      the route ID associated with the data
     * @return a new GpsTrackingDTO object containing the converted values
     */
    public static GpsTrackingDTO convertToDTO(ExternalGpsData externalData, int vehicleId, int routeId) {
        // Split location string
        String[] coords = externalData.getLocation().split(",");
        double latitude = Double.parseDouble(coords[0]);
        double longitude = Double.parseDouble(coords[1]);

        // Simulate auto-generated GPS ID
        int gpsId = (int)(Math.random() * 10000); 

        // Convert java.util.Date to java.sql.Timestamp
        Timestamp timestamp = new Timestamp(externalData.getRecordedAt().getTime());

        // Return converted DTO
        return new GpsTrackingDTO(gpsId, vehicleId, routeId, latitude, longitude, timestamp);
    }
}
