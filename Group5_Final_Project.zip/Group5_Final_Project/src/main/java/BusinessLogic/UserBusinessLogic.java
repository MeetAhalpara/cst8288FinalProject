package BusinessLogic;

import DAO.UserDAO;
import DAOImpl.UserDAOImpl;
import TransferObject.UserDTO;

/**
 * UserBusinessLogic handles the core business logic related to user operations.
 * 
 * It serves as a bridge between the controller (servlet) layer and the DAO layer,
 * and enforces rules such as preventing duplicate usernames during registration.
 * 
 * Author: Meet Ahalpara
 */
public class UserBusinessLogic {

    // DAO used to interact with the users table
    private final UserDAO userDAO;

    /**
     * Constructor that initializes the User DAO implementation.
     */
    public UserBusinessLogic() {
        this.userDAO = new UserDAOImpl();
    }

    /**
     * Registers a new user after checking if the username already exists.
     * 
     * This method prevents duplicate registrations and returns a status string
     * indicating the result of the operation.
     * 
     * @param user the user details to register
     * @return "exists" if the username is taken,
     *         "success" if the user was registered,
     *         "fail" if the registration failed
     */
    public String register(UserDTO user) {
        if (userDAO.isUsernameTaken(user.getUsername())) {
            return "exists";
        }

        boolean success = userDAO.registerUser(user);
        return success ? "success" : "fail";
    }

    /**
     * Attempts to log in a user with the given credentials.
     * 
     * @param username the username entered
     * @param password the password entered
     * @return a UserDTO object if login is successful, otherwise null
     */
    public UserDTO login(String username, String password) {
        return userDAO.loginUser(username, password);
    }
}
