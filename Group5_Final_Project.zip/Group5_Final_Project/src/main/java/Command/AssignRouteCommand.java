package Command;

import DAO.AssignmentDAO;
import TransferObject.AssignmentDTO;

/**
 * AssignRouteCommand is a command that assigns a vehicle to a route.
 * 
 * This class implements the Command Pattern. It wraps the logic of assigning a
 * route to a vehicle using the provided DAO and assignment data.
 * 
 * This allows the assignment to be triggered from anywhere, supporting
 * flexible and decoupled command execution.
 * 
 * Author: Meet Ahalpara
 */
public class AssignRouteCommand implements Command {

    // DAO used to perform the assignment
    private final AssignmentDAO dao;

    // Object containing vehicle and route assignment data
    private final AssignmentDTO assignment;

    /**
     * Creates a new AssignRouteCommand with the given DAO and assignment data.
     * 
     * @param dao the data access object used to assign the vehicle
     * @param assignment the assignment details including vehicle and route
     */
    public AssignRouteCommand(AssignmentDAO dao, AssignmentDTO assignment) {
        this.dao = dao;
        this.assignment = assignment;
    }

    /**
     * Executes the command to assign a vehicle to a route.
     * 
     * This method delegates the assignment operation to the DAO
     * and logs a confirmation message to the console.
     */
    @Override
    public void execute() {
        dao.assignVehicleToRoute(assignment);
        System.out.println("[Command] Assigned vehicle " + assignment.getVehicleId() +
                           " to route " + assignment.getRouteId());
    }
}
