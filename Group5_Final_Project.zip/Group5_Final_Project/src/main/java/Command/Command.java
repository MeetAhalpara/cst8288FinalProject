package Command;

/**
 * Command is a simple interface used to implement the Command Pattern.
 * 
 * It defines a single method, execute(), which can be used to trigger
 * specific actions. Different command classes will implement this interface
 * to perform different tasks (like assigning routes, updating statuses, etc.).
 * 
 * This pattern helps decouple the object that invokes the action from
 * the object that performs it.
 * 
 * Author: Meet Ahalpara
 */
public interface Command {

    /**
     * Executes the command.
     * 
     * Classes that implement this interface will define the specific logic
     * for the task they are meant to perform.
     */
    void execute();
}
