package Command;

/**
 * CommandExecutor is responsible for running commands that implement
 * the Command interface.
 * 
 * It provides a simple way to trigger the execution of any command
 * without needing to know the details of what the command does.
 * 
 * This is a key part of the Command Pattern and helps keep the logic
 * decoupled and flexible.
 * 
 * Author: Meet Ahalpara
 */
public class CommandExecutor {

    /**
     * Executes the given command.
     * 
     * This method calls the execute() method of the provided command,
     * allowing any action to be performed in a generic way.
     * 
     * @param command the command to execute
     */
    public void executeCommand(Command command) {
        command.execute();
    }
}
