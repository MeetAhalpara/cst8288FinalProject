package Controller;

import DAO.VehicleDAO;
import DAOImpl.VehicleDAOImpl;
import Strategy.DieselBusStrategy;
import Strategy.DieselElectricTrainStrategy;
import Strategy.ElectricRailStrategy;
import Strategy.FuelConsumptionContext;
import TransferObject.VehicleDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//@WebServlet("/AnalyticsServlet")

/**
 * AnalyticsServlet analyzes the fuel or energy consumption of all vehicles
 * and identifies which ones are consuming more than expected.
 * 
 * It uses the Strategy Pattern to apply different fuel consumption rules
 * depending on the type of vehicle (e.g., Diesel Bus, Electric Light Rail, etc.).
 * 
 * The servlet prepares a list of vehicles with excessive usage and forwards it
 * along with all vehicles to the analytics.jsp page for display.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
public class AnalyticsServlet extends HttpServlet {

    // DAO used to fetch vehicle data from the database
    private final VehicleDAO vehicleDAO = new VehicleDAOImpl();

    /**
     * Handles GET requests to perform analytics on vehicle fuel consumption.
     * 
     * It retrieves all vehicles, applies the appropriate strategy for each type,
     * and identifies vehicles that exceed normal consumption limits.
     * The result is forwarded to analytics.jsp for display.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<VehicleDTO> allVehicles = vehicleDAO.getAllVehicles();
        List<VehicleDTO> highConsumptionVehicles = new ArrayList<>();

        FuelConsumptionContext context = new FuelConsumptionContext();

        for (VehicleDTO vehicle : allVehicles) {
            String type = vehicle.getVehicleType();

            // Set the appropriate strategy based on vehicle type
            switch (type) {
                case "Diesel Bus":
                    context.setStrategy(new DieselBusStrategy());
                    break;
                case "Electric Light Rail":
                    context.setStrategy(new ElectricRailStrategy());
                    break;
                case "Diesel-Electric Train":
                    context.setStrategy(new DieselElectricTrainStrategy());
                    break;
                default:
                    continue; // Skip unknown types
            }

            // Check if the vehicle's consumption is excessive
            if (context.checkExcessive(vehicle)) {
                highConsumptionVehicles.add(vehicle);
            }
        }

        // Set attributes and forward to JSP
        request.setAttribute("alerts", highConsumptionVehicles);
        request.setAttribute("allVehicles", allVehicles);
        request.getRequestDispatcher("analytics.jsp").forward(request, response);
    }
}
