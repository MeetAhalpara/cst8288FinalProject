package Controller;

import DAO.UserRoleDAO;
import DAOImpl.UserRoleDAOImpl;
import TransferObject.UserDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

//@WebServlet("/AssignRoleServlet")

/**
 * AssignRoleServlet is used to assign roles to users in the system.
 * 
 * It handles form submissions where an admin can update user roles.
 * 
 * The servlet expects a list of users in the request and retrieves role values
 * from the submitted form to update each user's role.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
public class AssignRoleServlet extends HttpServlet {

    // DAO for assigning roles to users
    private final UserRoleDAO userRoleDAO = new UserRoleDAOImpl();

    /**
     * Handles GET requests by forwarding to the assignRole.jsp page.
     * 
     * This method does not perform any logic since role assignment is handled in POST.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Just forward to the JSP form
        request.getRequestDispatcher("assignRole.jsp").forward(request, response);
    }

    /**
     * Handles POST requests to assign roles to users.
     * 
     * It reads role values from the form inputs and updates each user's role.
     * After processing, it redirects to the admin dashboard.
     * If something goes wrong, it forwards back to the assignRole.jsp with an error.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Get the list of users from request attributes (assumed to be preloaded)
            List<UserDTO> users = (List<UserDTO>) request.getAttribute("users");

            // Loop through each user and assign the selected role
            for (UserDTO user : users) {
                String role = request.getParameter("userRoles" + user.getUserId());
                if (role != null) {
                    userRoleDAO.assignRole(user.getUserId(), role);
                }
            }

            // Redirect after successful role assignment
            response.sendRedirect("adminDashboard.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Failed to assign roles.");
            request.getRequestDispatcher("assignRole.jsp").forward(request, response);
        }
    }
}
