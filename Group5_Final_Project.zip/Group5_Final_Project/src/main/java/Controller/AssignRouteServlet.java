package Controller;

import DAO.VehicleDAO;
import DAO.RouteDAO;
import DAO.AssignmentDAO;
import DAOImpl.AssignmentDAOImpl;
import DAOImpl.VehicleDAOImpl;
import DAOImpl.RouteDAOImpl;
import TransferObject.AssignmentDTO;
import TransferObject.VehicleDTO;
import TransferObject.RouteDTO;
import Command.AssignRouteCommand;
import Command.CommandExecutor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

/**
 * AssignRouteServlet is used to assign a route to a selected vehicle.
 * 
 * This servlet displays the assignment form (doGet) and processes the
 * form submission (doPost). It uses the Command Pattern to encapsulate
 * the route assignment logic.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
@WebServlet("/assignRoute")
public class AssignRouteServlet extends HttpServlet {

    // DAOs to access vehicle and route data
    private final VehicleDAO vehicleDAO = new VehicleDAOImpl();
    private final RouteDAO routeDAO = new RouteDAOImpl();

    /**
     * Handles GET requests by loading all vehicles and routes,
     * then forwarding the data to assignRoute.jsp to display the form.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<VehicleDTO> vehicles = vehicleDAO.getAllVehicles();
        List<RouteDTO> routes = routeDAO.getAllRoutes();

        if (vehicles != null && routes != null) {
            request.setAttribute("vehicles", vehicles);
            request.setAttribute("routes", routes);
            request.getRequestDispatcher("assignRoute.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "Required data is missing.");
            request.getRequestDispatcher("assignRoute.jsp").forward(request, response);
        }
    }

    /**
     * Handles POST requests to process the assignment of a route to a vehicle.
     * 
     * It reads the submitted data, prepares an AssignmentDTO object, and uses
     * the Command Pattern to execute the route assignment. After that, it
     * fetches the updated list and forwards it to viewAssignedRoutes.jsp.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
        int routeId = Integer.parseInt(request.getParameter("routeId"));
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");

        // Create assignment data object
        AssignmentDTO dto = new AssignmentDTO();
        dto.setVehicleId(vehicleId);
        dto.setRouteId(routeId);
        dto.setStartDate(Date.valueOf(startDate));
        dto.setEndDate((endDate != null && !endDate.isEmpty()) ? Date.valueOf(endDate) : null);

        // Use Command Pattern to assign route
        AssignmentDAO dao = new AssignmentDAOImpl();
        AssignRouteCommand command = new AssignRouteCommand(dao, dto);
        CommandExecutor executor = new CommandExecutor();
        executor.executeCommand(command); // Execute assignment

        // Load updated assignment list and show it
        List<AssignmentDTO> assignments = dao.getAllAssignments();
        request.setAttribute("assignments", assignments);
        request.getRequestDispatcher("viewAssignedRoutes.jsp").forward(request, response);
    }
}
