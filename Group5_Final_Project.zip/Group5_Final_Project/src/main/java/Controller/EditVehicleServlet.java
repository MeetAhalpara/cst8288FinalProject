package Controller;

import DAO.VehicleDAO;
import DAOImpl.VehicleDAOImpl;
import TransferObject.VehicleDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * EditVehicleServlet is used to load and update details of a vehicle.
 * 
 * It supports two actions:
 * - Loading the edit form with the current vehicle details (GET)
 * - Saving the updated vehicle details after validation (POST)
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
@WebServlet("/editVehicle")
public class EditVehicleServlet extends HttpServlet {

    // DAO used to fetch and update vehicle data
    private final VehicleDAO vehicleDAO = new VehicleDAOImpl();

    /**
     * Handles GET requests to display the vehicle edit form.
     * 
     * It retrieves the vehicle by ID from the database and forwards the data
     * to editVehicle.jsp for editing.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int vehicleId = Integer.parseInt(request.getParameter("id"));
        VehicleDTO vehicle = vehicleDAO.getVehicleById(vehicleId);
        request.setAttribute("vehicle", vehicle);
        request.getRequestDispatcher("editVehicle.jsp").forward(request, response);
    }

    /**
     * Handles POST requests to update a vehicle's information.
     * 
     * It reads the form inputs, validates vehicle type and fuel type combination,
     * and updates the vehicle in the database if valid.
     * On success, redirects to the vehicle list. On failure, reloads the form with error.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
            String regNum = request.getParameter("registrationNumber");
            String model = request.getParameter("model");
            String vehicleType = request.getParameter("vehicleType");
            String fuelType = request.getParameter("fuelType");
            double consumption = Double.parseDouble(request.getParameter("consumptionRate"));
            int capacity = Integer.parseInt(request.getParameter("capacity"));
            String status = request.getParameter("status");

            // Validate vehicle type and fuel type combination
            if ((vehicleType.equals("Diesel Bus") && !(fuelType.equals("Diesel") || fuelType.equals("Hybrid"))) ||
                (vehicleType.equals("Electric Light Rail") && !fuelType.equals("Electric")) ||
                (vehicleType.equals("Diesel-Electric Train") && !(fuelType.equals("Diesel") || fuelType.equals("Electric") || fuelType.equals("Hybrid")))) {

                request.setAttribute("error", " Invalid combination of vehicle type and fuel type.");
                request.setAttribute("vehicle", vehicleDAO.getVehicleById(vehicleId)); // repopulate form
                request.getRequestDispatcher("editVehicle.jsp").forward(request, response);
                return;
            }

            // Prepare the updated vehicle object
            VehicleDTO vehicle = new VehicleDTO(vehicleId, regNum, model, vehicleType, fuelType, consumption, capacity, status);

            // Attempt to update the vehicle
            if (vehicleDAO.updateVehicle(vehicle)) {
                response.sendRedirect("viewVehicles");
            } else {
                request.setAttribute("error", "Update failed. Try again.");
                request.setAttribute("vehicle", vehicle);
                request.getRequestDispatcher("editVehicle.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Unexpected error: " + e.getMessage());
            request.getRequestDispatcher("editVehicle.jsp").forward(request, response);
        }
    }
}
