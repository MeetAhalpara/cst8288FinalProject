package Controller;

import Adapter.ExternalGpsData;
import Adapter.GpsDataAdapter;
import DAO.GpsTrackingDAO;
import DAOImpl.GpsTrackingDAOImpl;
import TransferObject.GpsTrackingDTO;
import Utility.DatabaseConnection;

import java.sql.Connection;
import java.util.Date;

/**
 * GpsTrackingInsertTest is a standalone test class used to simulate
 * inserting a GPS tracking record into the database.
 * 
 * It demonstrates how external GPS data can be adapted using the Adapter Pattern
 * and then saved using the DAO layer.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
public class GpsTrackingInsertTest {

    /**
     * Main method to run the GPS tracking insert test.
     * 
     * Steps:
     * 1. Simulates incoming external GPS data.
     * 2. Converts it to the internal DTO format using GpsDataAdapter.
     * 3. Inserts the converted data into the database using GpsTrackingDAO.
     * 
     * Output messages are printed to the console to verify success or failure.
     */
    public static void main(String[] args) {

        System.out.println(">>> Running GPS Tracking Insert Test");

        // Step 1: Simulate external GPS data
        ExternalGpsData externalData = new ExternalGpsData(
                "testDeviceXYZ",
                "43.712812,-79.432812",
                new Date()
        );

        // Step 2: Convert to internal DTO
        int vehicleId = 1;  // must exist in 'vehicles' table
        int routeId = 1;    // must exist in 'routes' table
        GpsTrackingDTO dto = GpsDataAdapter.convertToDTO(externalData, vehicleId, routeId);

        // Step 3: Insert into database
        try (Connection conn = DatabaseConnection.getConnection()) {
            GpsTrackingDAO dao = new GpsTrackingDAOImpl(conn);
            boolean inserted = dao.insertGpsData(dto);
            System.out.println("Inserted? " + inserted);
            System.out.println("Inserted DTO: " + dto);
        } catch (Exception e) {
            System.out.println(" ERROR: Could not insert GPS record.");
            e.printStackTrace();
        }

        System.out.println(">>> Test Finished");
    }
}
