package Controller;

import Adapter.ExternalGpsData;
import Adapter.GpsDataAdapter;
import TransferObject.GpsTrackingDTO;
import DAO.GpsTrackingDAO;
import DAOImpl.GpsTrackingDAOImpl;
import Utility.DatabaseConnection;

import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.util.Date;

//@WebServlet("/GpsTrackingServlet")

/**
 * GpsTrackingServlet simulates the process of receiving external GPS data,
 * converting it using the Adapter Pattern, and inserting it into the database.
 * 
 * This servlet is useful for testing GPS tracking integration in a live setup.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
public class GpsTrackingServlet extends HttpServlet {

    /**
     * Handles GET requests by simulating a GPS tracking input and storing it.
     * 
     * Steps:
     * 1. Simulate external GPS data.
     * 2. Convert it to the internal DTO format using GpsDataAdapter.
     * 3. Insert the data into the database using GpsTrackingDAO.
     * 
     * Prints results to the server console for testing and debugging.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println(">>> Reached GPS Tracking Servlet >>>");

        // Step 1: Simulate external GPS data
        ExternalGpsData externalData = new ExternalGpsData(
            "device999",
            "43.710812,-79.430812",
            new Date()
        );

        int vehicleId = 1; // ensure this vehicle exists in the database
        int routeId = 1;   // ensure this route exists in the database

        // Step 2: Convert to internal DTO
        GpsTrackingDTO dto = GpsDataAdapter.convertToDTO(externalData, vehicleId, routeId);
        System.out.println("DTO Ready: " + dto);

        // Step 3: Insert into the database
        boolean inserted = false;
        try (Connection conn = DatabaseConnection.getConnection()) {
            GpsTrackingDAO dao = new GpsTrackingDAOImpl(conn);
            inserted = dao.insertGpsData(dto);
            System.out.println("Inserted? " + inserted);
        } catch (Exception e) {
            System.out.println(" Error during DB Insert:");
            e.printStackTrace();
        }
    }
}
