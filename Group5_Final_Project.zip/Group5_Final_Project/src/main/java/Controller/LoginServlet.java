package Controller;

import TransferObject.UserDTO;
import Utility.DatabaseConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

/**
 * LoginServlet handles user authentication and redirects users
 * based on their assigned role: Admin, Manager, or Operator.
 * 
 * It checks the credentials against the database, and if valid,
 * creates a session and sends the user to their respective dashboard.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    /**
     * Handles POST requests to perform user login.
     * 
     * It retrieves email and password from the form, checks the database,
     * verifies the role, and creates a session for the authenticated user.
     * If login fails or the role is unknown, it shows an error on the login page.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email").trim();
        String password = request.getParameter("password").trim();

        String sql = "SELECT u.*, r.role_name FROM users u " +
                     "JOIN user_roles ur ON u.user_id = ur.user_id " +
                     "JOIN roles r ON ur.role_id = r.role_id " +
                     "WHERE LOWER(u.email) = LOWER(?) AND u.password = ?";

        System.out.println("Email entered: " + email);
        System.out.println("Password entered: " + password);

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String username = rs.getString("username");
                    String role = rs.getString("role_name");

                    // Special rule: Only official Admin can login as Admin
                    if ("Admin".equalsIgnoreCase(role)) {
                        if ("cst8288".equals(username) && "cst8288@ptfms.com".equals(email)) {
                            loginSuccess(request, response, rs, role);
                        } else {
                            request.setAttribute("error", "Only the official Admin (cst8288) can log in as Admin.");
                            request.getRequestDispatcher("login.jsp").forward(request, response);
                        }
                        return;
                    }

                    // Redirect based on role
                    if ("Manager".equalsIgnoreCase(role) || "Operator".equalsIgnoreCase(role)) {
                        loginSuccess(request, response, rs, role);
                    } else {
                        request.setAttribute("error", "Role is not recognized.");
                        request.getRequestDispatcher("login.jsp").forward(request, response);
                    }
                } else {
                    request.setAttribute("error", "Invalid email or password.");
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Something went wrong.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    /**
     * Helper method that creates the user session and redirects based on role.
     * 
     * @param request the HttpServletRequest object
     * @param response the HttpServletResponse object
     * @param rs the ResultSet containing user info
     * @param role the role name (Admin, Manager, or Operator)
     * @throws Exception if an error occurs during redirection
     */
    private void loginSuccess(HttpServletRequest request, HttpServletResponse response, ResultSet rs, String role)
            throws Exception {
        HttpSession session = request.getSession();
        UserDTO user = new UserDTO();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));

        session.setAttribute("currentUser", user);
        session.setAttribute("role", role);

        // Redirect to appropriate dashboard based on role
        switch (role.toLowerCase()) {
            case "admin":
                response.sendRedirect("admin.jsp");
                break;
            case "manager":
                response.sendRedirect("manager.jsp");
                break;
            case "operator":
                response.sendRedirect("operator.jsp");
                break;
            default:
                response.sendRedirect("login.jsp?message=Unknown role");
        }
    }
}
