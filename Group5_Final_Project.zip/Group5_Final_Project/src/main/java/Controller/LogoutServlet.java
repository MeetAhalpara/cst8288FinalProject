package Controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * LogoutServlet handles user logout by ending the current session
 * and redirecting the user back to the login page with a message.
 * 
 * This helps ensure users are properly logged out and their session
 * data is cleared from the server.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {

    /**
     * Handles GET requests to perform logout.
     * 
     * If a session exists, it is invalidated (cleared).
     * Then the user is redirected to the login page with a logout confirmation message.
     *
     * @param request  the HTTP request
     * @param response the HTTP response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get existing session without creating a new one
        HttpSession session = request.getSession(false);

        // Invalidate session if it exists
        if (session != null) {
            session.invalidate();
        }

        // Redirect to login page with message
        response.sendRedirect("login.jsp?message=Logged out successfully");
    }
}
