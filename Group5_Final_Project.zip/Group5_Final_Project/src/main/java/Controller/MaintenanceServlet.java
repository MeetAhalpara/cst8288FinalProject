package Controller;

import DAO.MaintenanceDAO;
import DAO.VehicleDAO;
import DAOImpl.MaintenanceDAOImpl;
import DAOImpl.VehicleDAOImpl;
import TransferObject.MaintenanceDTO;
import TransferObject.VehicleDTO;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

/**
 * MaintenanceServlet handles viewing, adding, editing, updating, and deleting
 * maintenance records for vehicles.
 * 
 * It loads maintenance data and available vehicles from the database,
 * and forwards to appropriate JSP pages for form display or results.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
public class MaintenanceServlet extends HttpServlet {

    // DAOs for accessing maintenance and vehicle data
    private final MaintenanceDAO maintenanceDAO = new MaintenanceDAOImpl();
    private final VehicleDAO vehicleDAO = new VehicleDAOImpl();

    /**
     * Handles GET requests for various maintenance actions.
     * 
     * Actions supported:
     * - addForm: Shows the form to add a new maintenance record
     * - edit: Loads a specific maintenance record for editing
     * - update: Preloads data for update in the edit form
     * - delete: Deletes a maintenance record by ID
     * - default: Loads all maintenance alerts for display
     * 
     * @param request  the HTTP request
     * @param response the HTTP response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        try {
            if ("addForm".equalsIgnoreCase(action)) {
                List<VehicleDTO> vehicles = vehicleDAO.getAllVehicles();
                request.setAttribute("vehicles", vehicles);
                request.getRequestDispatcher("add_maintenance.jsp").forward(request, response);

            } else if ("edit".equalsIgnoreCase(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                MaintenanceDTO maintenance = maintenanceDAO.getMaintenanceById(id);
                List<VehicleDTO> vehicles = vehicleDAO.getAllVehicles();
                request.setAttribute("maintenance", maintenance);
                request.setAttribute("vehicles", vehicles);
                request.getRequestDispatcher("editMaintenance.jsp").forward(request, response);

            } else if ("delete".equalsIgnoreCase(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                maintenanceDAO.deleteMaintenanceRecord(id);
                response.sendRedirect("maintenance");

            } else if ("update".equalsIgnoreCase(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                MaintenanceDTO maintenance = maintenanceDAO.getMaintenanceById(id);
                List<VehicleDTO> vehicles = vehicleDAO.getAllVehicles();

                request.setAttribute("maintenance", maintenance);
                request.setAttribute("vehicles", vehicles);
                request.getRequestDispatcher("editMaintenance.jsp").forward(request, response);

            } else {
                List<MaintenanceDTO> maintenanceList = maintenanceDAO.getMaintenanceAlerts();
                request.setAttribute("maintenance", maintenanceList);
                request.getRequestDispatcher("Maintenance.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Something went wrong.");
            request.getRequestDispatcher("editMaintenance.jsp").forward(request, response);
        }
    }

    /**
     * Handles POST requests to insert or update a maintenance record.
     * 
     * It reads data from the submitted form, constructs a DTO, and passes it
     * to the DAO for insert or update depending on the action.
     * After saving, it redirects back to the maintenance list.
     * 
     * @param request  the HTTP request
     * @param response the HTTP response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String action = request.getParameter("action");

            int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
            Date maintenanceDate = Date.valueOf(request.getParameter("maintenanceDate"));
            double cost = Double.parseDouble(request.getParameter("cost"));
            String details = request.getParameter("details");

            // Create DTO from form data
            MaintenanceDTO maintenance = new MaintenanceDTO();
            maintenance.setVehicleId(vehicleId);
            maintenance.setMaintenanceDate(maintenanceDate);
            maintenance.setCost(cost);
            maintenance.setDetails(details);

            // Handle update vs insert
            if ("update".equalsIgnoreCase(action)) {
                int maintenanceId = Integer.parseInt(request.getParameter("maintenanceId"));
                maintenance.setMaintenanceId(maintenanceId);
                maintenanceDAO.updateMaintenanceRecord(maintenance);
            } else {
                maintenanceDAO.insertMaintenanceRecord(maintenance);
            }

            // Redirect to main maintenance page
            response.sendRedirect("maintenance");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Something went wrong.");
            doGet(request, response);
        }
    }
}
