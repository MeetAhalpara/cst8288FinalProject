package Controller;

import BusinessLogic.UserBusinessLogic;
import TransferObject.UserDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * RegisterServlet handles user registration for new Operators or Managers.
 * 
 * It collects the username, password, and role from the registration form,
 * automatically generates an email based on the role, and sends the data to
 * the business logic layer for processing.
 * 
 * After registration:
 * - If the username already exists, it redirects to the login page with a message.
 * - If registration is successful, it redirects to a confirmation page.
 * - If it fails, the user is redirected back to the registration form with an error.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
@WebServlet("/register")    
public class RegisterServlet extends HttpServlet {

    // Business logic for user operations
    private final UserBusinessLogic userLogic = new UserBusinessLogic();

    /**
     * Handles POST requests to register a new user.
     * 
     * Steps:
     * 1. Read form data: username, password, and role ID.
     * 2. Generate an email address based on role.
     * 3. Create a UserDTO and send it to the business logic layer.
     * 4. Redirect or forward based on the result of registration.
     * 
     * @param request  the HTTP request containing form data
     * @param response the HTTP response to be sent back
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username").trim();
        String password = request.getParameter("password").trim();
        int roleId = Integer.parseInt(request.getParameter("roleId"));

        // Email generation based on role
        String roleSuffix = (roleId == 3) ? ".ma@ptfms.com" : ".op@ptfms.com";
        String email = username + roleSuffix;

        // Create a user object to register
        UserDTO user = new UserDTO();
        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        user.setRoleId(roleId);

        // Attempt to register the user
        String result = userLogic.register(user);

        // Handle the result
        switch (result) {
            case "exists":
                response.sendRedirect("login.jsp?message=User already exists. Please login.");
                break;
            case "success":
                response.sendRedirect("register_success.jsp?email=" + email);
                break;
            case "fail":
            default:
                request.setAttribute("error", "Registration failed. Try again.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
                break;
        }
    }
}
