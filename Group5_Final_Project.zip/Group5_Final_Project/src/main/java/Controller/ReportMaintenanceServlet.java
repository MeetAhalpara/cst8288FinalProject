package Controller;

import DAO.MaintenanceDAO;
import DAOImpl.MaintenanceDAOImpl;
import TransferObject.MaintenanceDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;

/**
 * ReportMaintenanceServlet allows Operators to report maintenance issues
 * for vehicles by submitting a form.
 * 
 * It reads the form data, creates a MaintenanceDTO, and inserts the record
 * into the database using the DAO layer.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
@WebServlet("/reportMaintenance")
public class ReportMaintenanceServlet extends HttpServlet {

    // DAO to handle database operations for maintenance
    private final MaintenanceDAO maintenanceDAO = new MaintenanceDAOImpl();

    /**
     * Handles POST requests for reporting maintenance issues.
     * 
     * Steps:
     * 1. Read form data: vehicleId, date, cost, and details.
     * 2. Create a MaintenanceDTO object.
     * 3. Insert the record using the DAO.
     * 4. Redirect to the Operator dashboard on success,
     *    or back to the form with an error message on failure.
     * 
     * @param request  the HTTP request containing form data
     * @param response the HTTP response to be sent back
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
            Date maintenanceDate = Date.valueOf(request.getParameter("date"));
            double cost = Double.parseDouble(request.getParameter("cost"));
            String details = request.getParameter("details");

            // Create DTO object with form data
            MaintenanceDTO record = new MaintenanceDTO();
            record.setVehicleId(vehicleId);
            record.setMaintenanceDate(maintenanceDate);
            record.setCost(cost);
            record.setDetails(details);

            // Insert record and handle result
            if (maintenanceDAO.insertMaintenanceRecord(record)) {
                response.sendRedirect("operator.jsp?message=Maintenance issue reported successfully!");
            } else {
                request.setAttribute("error", "Failed to report maintenance issue.");
                request.getRequestDispatcher("report_issue.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Invalid input. Try again.");
            request.getRequestDispatcher("report_issue.jsp").forward(request, response);
        }
    }
}
