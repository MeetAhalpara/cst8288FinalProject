package Controller;

import DAO.VehicleDAO;
import DAOImpl.VehicleDAOImpl;
import TransferObject.VehicleDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

//@WebServlet("/VehicleServlet")

/**
 * VehicleServlet handles vehicle-related actions such as adding,
 * editing, and deleting vehicle records.
 * 
 * - GET: Used for delete or edit redirection.
 * - POST: Used for creating or updating vehicle records with validation.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
public class VehicleServlet extends HttpServlet {

    // DAO for database access
    private final VehicleDAO vehicleDAO = new VehicleDAOImpl();

    /**
     * Handles GET requests to either display a vehicle for editing
     * or delete a vehicle by its ID.
     * 
     * @param request  the HTTP request with parameters like action and vehicleId
     * @param response the HTTP response to send back
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("update".equalsIgnoreCase(action)) {
            int id = Integer.parseInt(request.getParameter("vehicleId"));
            VehicleDTO vehicle = vehicleDAO.getVehicleById(id);

            if (vehicle != null) {
                request.setAttribute("vehicle", vehicle);
                request.getRequestDispatcher("editVehicle.jsp").forward(request, response);
            } else {
                request.setAttribute("error", " Vehicle not found or not passed correctly from servlet.");
                request.getRequestDispatcher("editVehicle.jsp").forward(request, response);
            }

        } else if ("delete".equalsIgnoreCase(action)) {
            int id = Integer.parseInt(request.getParameter("vehicleId"));
            boolean deleted = vehicleDAO.deleteVehicle(id);

            if (deleted) {
                response.sendRedirect("viewVehicles");
            } else {
                request.setAttribute("error", " Failed to delete vehicle.");
                request.getRequestDispatcher("vehicles.jsp").forward(request, response);
            }
        }
    }

    /**
     * Handles POST requests to add or update vehicle details.
     * 
     * Validates vehicle and fuel type compatibility before inserting or updating.
     * Redirects to the vehicle list on success, or reloads the form with an error on failure.
     * 
     * @param request  the HTTP request with form data
     * @param response the HTTP response to send back
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String vehicleIdStr = request.getParameter("vehicleId");

        try {
            String regNum = request.getParameter("registrationNumber");
            String model = request.getParameter("model");
            String vehicleType = request.getParameter("vehicleType");
            String fuelType = request.getParameter("fuelType");
            double consumption = Double.parseDouble(request.getParameter("consumptionRate"));
            int capacity = Integer.parseInt(request.getParameter("capacity"));
            String status = request.getParameter("status");

            // Validate compatibility between vehicle type and fuel type
            if ((vehicleType.equals("Diesel Bus") && !(fuelType.equals("Diesel") || fuelType.equals("Hybrid"))) ||
                (vehicleType.equals("Electric Light Rail") && !fuelType.equals("Electric")) ||
                (vehicleType.equals("Diesel-Electric Train") && !(fuelType.equals("Diesel") || fuelType.equals("Electric") || fuelType.equals("Hybrid")))) {
                request.setAttribute("error", " Invalid combination of vehicle type and fuel type.");
                request.setAttribute("vehicle", new VehicleDTO());
                request.getRequestDispatcher(vehicleIdStr != null ? "editVehicle.jsp" : "addVehicle.jsp").forward(request, response);
                return;
            }

            // Prepare DTO
            VehicleDTO vehicle = new VehicleDTO();
            vehicle.setRegistrationNumber(regNum);
            vehicle.setModel(model);
            vehicle.setVehicleType(vehicleType);
            vehicle.setFuelType(fuelType);
            vehicle.setConsumptionRate(consumption);
            vehicle.setCapacity(capacity);
            vehicle.setStatus(status);

            // Determine if we are adding or updating
            if (vehicleIdStr != null && !vehicleIdStr.trim().isEmpty()) {
                int id = Integer.parseInt(vehicleIdStr);
                vehicle.setVehicleId(id);
                boolean updated = vehicleDAO.updateVehicle(vehicle);

                if (updated) {
                    response.sendRedirect("viewVehicles");
                } else {
                    request.setAttribute("error", "Update failed.");
                    request.setAttribute("vehicle", vehicle);
                    request.getRequestDispatcher("editVehicle.jsp").forward(request, response);
                }
            } else {
                boolean success = vehicleDAO.addVehicle(vehicle);
                if (success) {
                    response.sendRedirect("viewVehicles");
                } else {
                    request.setAttribute("error", "Vehicle not added. It may already exist.");
                    request.getRequestDispatcher("addVehicle.jsp").forward(request, response);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Something went wrong. Check inputs.");
            request.getRequestDispatcher(vehicleIdStr != null ? "editVehicle.jsp" : "addVehicle.jsp").forward(request, response);
        }
    }
}
