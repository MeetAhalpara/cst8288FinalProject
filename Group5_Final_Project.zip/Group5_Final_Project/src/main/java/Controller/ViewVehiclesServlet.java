package Controller;

import DAO.VehicleDAO;
import DAOImpl.VehicleDAOImpl;
import TransferObject.UserDTO;
import TransferObject.VehicleDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

/**
 * ViewVehiclesServlet displays a list of vehicles based on the user's role.
 * 
 * - If the logged-in user is a Manager, all vehicles will be shown.
 * - If the user is an Operator, only vehicles assigned to them will be displayed.
 * 
 * The servlet ensures the user is authenticated and forwards the result to `vehicles.jsp`.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
@WebServlet("/viewVehicles")
public class ViewVehiclesServlet extends HttpServlet {

    // DAO for accessing vehicle data
    private final VehicleDAO vehicleDAO = new VehicleDAOImpl();

    /**
     * Handles GET requests to retrieve vehicle data.
     * 
     * Steps:
     * 1. Check if the user is logged in and get their role.
     * 2. Fetch all vehicles if Manager, or only assigned ones if Operator.
     * 3. Forward the list to vehicles.jsp for display.
     * 
     * Redirects to login.jsp if the session is missing or invalid.
     *
     * @param request  the HTTP request
     * @param response the HTTP response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        UserDTO currentUser = (UserDTO) session.getAttribute("currentUser");
        String role = (String) session.getAttribute("role");

        if (currentUser == null || role == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        List<VehicleDTO> vehicleList;

        if ("Manager".equalsIgnoreCase(role)) {
            // Managers can view all vehicles
            vehicleList = vehicleDAO.getAllVehicles();
        } else {
            // Operators can view only their assigned vehicles
            vehicleList = vehicleDAO.getVehiclesByOperatorId(currentUser.getUserId());
        }

        request.setAttribute("vehicles", vehicleList);
        request.getRequestDispatcher("vehicles.jsp").forward(request, response);
    }
}
