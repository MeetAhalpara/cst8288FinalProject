package Controller;

import DAO.VehicleDAO;
import DAOImpl.VehicleDAOImpl;
import TransferObject.VehicleDTO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * updateVehicleStatus handles updating a vehicle's status by the operator.
 * 
 * After the update is successful, it triggers the Observer Pattern to notify
 * maintenance and analytics observers.
 * 
 * This ensures that other system components (like alerts or dashboards) stay up to date.
 * 
 * Author: Meet Ahalpara and Krish Patel
 */
@WebServlet("/updateVehicleStatus")
public class updateVehicleStatus extends HttpServlet {

    // DAO to access and update vehicle information
    private final VehicleDAO vehicleDAO = new VehicleDAOImpl();

    /**
     * Handles POST requests to update the status of a vehicle.
     * 
     * Steps:
     * 1. Read vehicle ID and new status from the form.
     * 2. Update the status in the database.
     * 3. If successful:
     *    - Fetch updated vehicle object
     *    - Trigger Observer Pattern: notify maintenance and analytics observers
     *    - Redirect with success message
     * 4. If failed:
     *    - Forward back to the form with an error message
     *
     * @param request  the HTTP request containing vehicleId and new status
     * @param response the HTTP response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int vehicleId = Integer.parseInt(request.getParameter("vehicleId"));
        String newStatus = request.getParameter("status");

        boolean updated = vehicleDAO.updateVehicleStatus(vehicleId, newStatus);

        if (updated) {
            // Fetch the updated vehicle object
            VehicleDTO updatedVehicle = vehicleDAO.getVehicleById(vehicleId);

            // Trigger Observer Pattern
            Observer.MaintenanceObserver maintenanceObserver = new Observer.MaintenanceObserver();
            Observer.AnalyticsObserver analyticsObserver = new Observer.AnalyticsObserver();
            Observer.VehicleStatusNotifier notifier = new Observer.VehicleStatusNotifier();

            notifier.addObserver(maintenanceObserver);
            notifier.addObserver(analyticsObserver);

            notifier.notifyObservers(updatedVehicle);

            // Redirect to Operator Dashboard with message
            response.sendRedirect("operator.jsp?message=Status updated successfully!");

        } else {
            request.setAttribute("error", "Failed to update status.");
            request.getRequestDispatcher("updateVehicleStatus.jsp").forward(request, response);
        }
    }
}
