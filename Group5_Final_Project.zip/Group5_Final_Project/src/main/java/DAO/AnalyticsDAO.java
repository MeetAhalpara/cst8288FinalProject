package DAO;

import java.util.Map;

/**
 * AnalyticsDAO defines methods for retrieving analytics-related data
 * from the system such as vehicle status distribution, maintenance cost,
 * and fuel consumption summary.
 * 
 * These methods are intended to be implemented by DAOImpl classes to
 * support dashboard/reporting features.
 * 
 * Author: Meet Ahalpara
 */
public interface AnalyticsDAO {

    /**
     * Gets the count of vehicles grouped by their current status
     * (e.g., Active, In Maintenance, Idle).
     * 
     * @return a map where keys are status names and values are the number of vehicles in that status
     */
    Map<String, Integer> getVehicleStatusCounts();

    /**
     * Calculates the total cost of all recorded maintenance activities.
     * 
     * @return the sum of maintenance costs from the database
     */
    double getTotalMaintenanceCost();

    /**
     * Retrieves a summary of average fuel consumption grouped by fuel type.
     * 
     * For example, it may return:
     * - "Diesel" → 12.5
     * - "Electric" → 5.2
     * 
     * @return a map where keys are fuel types and values are average consumption rates
     */
    Map<String, Double> getFuelConsumptionSummary();
}
