package DAO;

import TransferObject.AssignmentDTO;
import java.util.List;

/**
 * AssignmentDAO defines database operations related to assigning vehicles to routes.
 * 
 * This interface supports:
 * - Assigning a vehicle to a route
 * - Retrieving all existing assignments
 * 
 * It is intended to be implemented by AssignmentDAOImpl.
 * 
 * Author: Meet Ahalpara
 */
public interface AssignmentDAO {

    /**
     * Assigns a vehicle to a specific route for a given date range.
     * 
     * @param assignment the AssignmentDTO object containing vehicle ID, route ID,
     *                   start date, and optionally end date
     * @return true if the assignment was successfully inserted, false otherwise
     */
    boolean assignVehicleToRoute(AssignmentDTO assignment); 

    /**
     * Retrieves a list of all route assignments from the database.
     * 
     * @return a list of AssignmentDTO objects representing all current assignments
     */
    List<AssignmentDTO> getAllAssignments();
}
