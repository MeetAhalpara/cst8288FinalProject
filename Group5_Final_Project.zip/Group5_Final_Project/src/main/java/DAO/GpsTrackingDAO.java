package DAO;

import TransferObject.GpsTrackingDTO;

/**
 *
 * @author Meet Ahalpara
 */
public interface GpsTrackingDAO {

    /**
     *
     * @param gpsData
     * @return
     */
    boolean insertGpsData(GpsTrackingDTO gpsData);
}
