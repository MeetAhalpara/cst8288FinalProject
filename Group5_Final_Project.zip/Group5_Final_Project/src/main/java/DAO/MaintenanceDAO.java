    package DAO;

import TransferObject.MaintenanceDTO;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Meet Ahalpara
 */
public interface MaintenanceDAO {

    /**
     *
     * @param maintenance
     * @return
     */
    boolean insertMaintenanceRecord(MaintenanceDTO maintenance);

    /**
     *
     * @return
     */
    List<MaintenanceDTO> getMaintenanceAlerts();

    /**
     *
     * @return
     */
    List<MaintenanceDTO> getAllMaintenanceAlerts();

    /**
     *
     * @param vehicleId
     * @return
     */
    List<MaintenanceDTO> getMaintenanceByVehicle(int vehicleId);

    /**
     *
     * @param status
     * @return
     */
    List<MaintenanceDTO> getMaintenanceByStatus(String status);

    /**
     *
     * @param maintenance
     * @return
     */
    boolean updateMaintenanceRecord(MaintenanceDTO maintenance);

    /**
     *
     * @param maintenanceId
     * @return
     */
    boolean deleteMaintenanceRecord(int maintenanceId);

    /**
     *
     * @param maintenanceId
     * @return
     */
    MaintenanceDTO getMaintenanceById(int maintenanceId);

}
