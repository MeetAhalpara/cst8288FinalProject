/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import TransferObject.RouteDTO;
import java.util.List;
/**
 *
 * @author Meet Ahalpara
 */
public interface RouteDAO {

    /**
     *
     * @return
     */
    List<RouteDTO> getAllRoutes();  // Method to fetch all routes

    /**
     *
     * @param routeId
     * @return
     */
    RouteDTO getRouteById(int routeId);  // Method to get a route by its ID

    /**
     *
     * @param route
     * @return
     */
    boolean addRoute(RouteDTO route);  // Method to add a new route

    /**
     *
     * @param route
     * @return
     */
    boolean updateRoute(RouteDTO route);  // Method to update an existing route

    /**
     *
     * @param routeId
     * @return
     */
    boolean deleteRoute(int routeId);  // Method to delete a route
    
}
