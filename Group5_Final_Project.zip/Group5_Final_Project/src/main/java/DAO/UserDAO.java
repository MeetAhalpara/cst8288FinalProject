package DAO;

import TransferObject.UserDTO;
import java.util.List;

/**
 *
 * @author Meet Ahalpara
 */
public interface UserDAO {

    /**
     *
     * @param user
     * @return
     */
    boolean registerUser(UserDTO user);

    /**
     *
     * @param username
     * @param password
     * @return
     */
    UserDTO loginUser(String username, String password);

    /**
     *
     * @param username
     * @return
     */
    boolean isUsernameTaken(String username);

    // New method to get users by their roles

    /**
     *
     * @param role
     * @return
     */
    List<UserDTO> getUsersByRole(String role);

    /**
     *
     * @return
     */
    List<UserDTO> getAllUsers();
    // New method to assign a role to a user

    /**
     *
     * @param userId
     * @param role
     * @return
     */
    boolean assignRoleToUser(int userId, String role);
}
