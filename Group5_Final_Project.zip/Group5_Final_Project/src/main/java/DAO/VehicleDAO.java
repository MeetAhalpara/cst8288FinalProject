package DAO;

import TransferObject.VehicleDTO;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Meet Ahalpara
 */
public interface VehicleDAO {
//    Operator

    /**
     *
     * @param userId
     * @return
     */
    List<VehicleDTO> getVehiclesByOperatorId(int userId);

    /**
     *
     * @param vehicleId
     * @param newStatus
     * @return
     */
    boolean updateVehicleStatus(int vehicleId, String newStatus);

    /**
     *
     * @param userId
     * @return
     */
    Map<String, Integer> getVehicleStatusCountsByOperator(int userId);
    
    
//    Manager: 

    /**
     *
     * @param vehicle
     * @return
     */
    boolean addVehicle(VehicleDTO vehicle);

    /**
     *
     * @param vehicle
     * @return
     */
    boolean updateVehicle(VehicleDTO vehicle);

    /**
     *
     * @param vehicleId
     * @return
     */
    boolean deleteVehicle(int vehicleId);

    /**
     *
     * @param vehicleId
     * @return
     */
    VehicleDTO getVehicleById(int vehicleId);

    /**
     *
     * @return
     */
    List<VehicleDTO> getAllVehicles();

    /**
     *
     * @param vehicleId
     * @param routeId
     * @return
     */
    boolean assignRouteToVehicle(int vehicleId, int routeId);  

    /**
     *
     * @param vehicleId
     * @param routeId
     * @param startDate
     * @param endDate
     * @return
     */
    public boolean assignRouteToVehicle(int vehicleId, int routeId, String startDate, String endDate);
    
}
