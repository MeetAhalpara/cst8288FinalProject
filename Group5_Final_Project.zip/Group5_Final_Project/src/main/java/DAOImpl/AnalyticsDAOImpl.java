package DAOImpl;

import DAO.AnalyticsDAO;
import Utility.DatabaseConnection;
import java.sql.*;
import java.util.*;

/**
 * AnalyticsDAOImpl implements the AnalyticsDAO interface to provide
 * database access for vehicle status analytics, maintenance cost totals,
 * and fuel consumption summaries.
 * 
 * It uses JDBC to connect to the database and run aggregated SQL queries.
 * 
 * Author: Meet Ahalpara
 */
public class AnalyticsDAOImpl implements AnalyticsDAO {

    /**
     * Retrieves the number of vehicles grouped by their current status.
     * 
     * For example:
     * - "Active" → 5
     * - "In Maintenance" → 2
     * - "Idle" → 3
     * 
     * @return a map where the key is the vehicle status and the value is the count
     */
    @Override
    public Map<String, Integer> getVehicleStatusCounts() {
        Map<String, Integer> statusCounts = new HashMap<>();
        String query = "SELECT status, COUNT(*) as count FROM vehicles GROUP BY status";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                statusCounts.put(rs.getString("status"), rs.getInt("count"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return statusCounts;
    }

    /**
     * Calculates the total maintenance cost by summing all maintenance record costs.
     * 
     * Example output: 10500.75
     * 
     * @return the total cost from the maintenance table, or 0.0 if an error occurs
     */
    @Override
    public double getTotalMaintenanceCost() {
        String query = "SELECT SUM(cost) FROM maintenance";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    /**
     * Retrieves total fuel/energy consumption grouped by fuel type.
     * 
     * For example:
     * - "Diesel" → 250.0
     * - "Electric" → 120.5
     * 
     * @return a map where the key is the fuel type and the value is the total consumption
     */
    @Override
    public Map<String, Double> getFuelConsumptionSummary() {
        Map<String, Double> fuelData = new HashMap<>();
        String query = "SELECT fuel_type, SUM(consumption_rate) as total FROM vehicles GROUP BY fuel_type";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                fuelData.put(rs.getString("fuel_type"), rs.getDouble("total"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return fuelData;
    }
}
