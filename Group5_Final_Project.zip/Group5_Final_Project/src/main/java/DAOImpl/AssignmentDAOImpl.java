package DAOImpl;

import DAO.AssignmentDAO;
import TransferObject.AssignmentDTO;
import Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * AssignmentDAOImpl provides the implementation for assigning vehicles to routes
 * and retrieving all route assignments.
 * 
 * It prevents duplicate assignments and allows easy access to assignment data
 * for display and reporting.
 * 
 * Author: Meet Ahalpara
 */
public class AssignmentDAOImpl implements AssignmentDAO {

    /**
     * Assigns a vehicle to a route by inserting a new record into the `assignments` table.
     * 
     * Before inserting, it checks if the vehicle is already assigned to the same route
     * to prevent duplication.
     * 
     * @param assignment an AssignmentDTO containing vehicleId, routeId, startDate, and optional endDate
     * @return true if assignment is successfully inserted; false if it already exists or an error occurs
     */
    @Override
    public boolean assignVehicleToRoute(AssignmentDTO assignment) {
        // First, check if the assignment already exists
        String checkSql = "SELECT COUNT(*) FROM assignments WHERE vehicle_id = ? AND route_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement checkPs = conn.prepareStatement(checkSql)) {

            checkPs.setInt(1, assignment.getVehicleId());
            checkPs.setInt(2, assignment.getRouteId());
            ResultSet checkRs = checkPs.executeQuery();
            checkRs.next();

            if (checkRs.getInt(1) > 0) {
                System.out.println("🚫 This vehicle is already assigned to the specified route.");
                return false; // Prevent duplicate assignment
            }

            // Insert new assignment
            String sql = "INSERT INTO assignments (vehicle_id, route_id, start_date, end_date) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, assignment.getVehicleId());
                ps.setInt(2, assignment.getRouteId());
                ps.setDate(3, assignment.getStartDate());

                if (assignment.getEndDate() != null) {
                    ps.setDate(4, assignment.getEndDate());
                } else {
                    ps.setNull(4, java.sql.Types.DATE);
                }

                return ps.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Retrieves a list of all vehicle-route assignments, including route name
     * and vehicle registration number for display purposes.
     * 
     * @return a list of AssignmentDTO objects representing all route assignments
     */
    @Override
    public List<AssignmentDTO> getAllAssignments() {
        List<AssignmentDTO> assignments = new ArrayList<>();
        String sql = "SELECT DISTINCT a.vehicle_id, r.route_name, a.start_date, a.end_date, v.registration_number " +
                     "FROM assignments a " +
                     "JOIN routes r ON a.route_id = r.route_id " +
                     "JOIN vehicles v ON a.vehicle_id = v.vehicle_id"; 

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                AssignmentDTO assignment = new AssignmentDTO();
                assignment.setVehicleId(rs.getInt("vehicle_id"));
                assignment.setRouteName(rs.getString("route_name"));
                assignment.setStartDate(rs.getDate("start_date"));
                assignment.setEndDate(rs.getDate("end_date"));
                assignment.setVehicleRegistrationNumber(rs.getString("registration_number"));
                assignments.add(assignment);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return assignments;
    }
}
