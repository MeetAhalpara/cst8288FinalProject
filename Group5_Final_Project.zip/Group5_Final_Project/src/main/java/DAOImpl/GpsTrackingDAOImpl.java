package DAOImpl;

import DAO.GpsTrackingDAO;
import TransferObject.GpsTrackingDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Meet Ahalpara
 */
public class GpsTrackingDAOImpl implements GpsTrackingDAO {

    private final Connection connection;

    /**
     *
     * @param connection
     */
    public GpsTrackingDAOImpl(Connection connection) {
        this.connection = connection;
    }

    /**
     *
     * @param gpsData
     * @return
     */
    @Override
    public boolean insertGpsData(GpsTrackingDTO gpsData) {
        String sql = "INSERT INTO gps_tracking (vehicle_id, route_id, latitude, longitude, timestamp) " +
                     "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, gpsData.getVehicleId());
            stmt.setInt(2, gpsData.getRouteId());
            stmt.setDouble(3, gpsData.getLatitude());
            stmt.setDouble(4, gpsData.getLongitude());
            stmt.setTimestamp(5, gpsData.getTimestamp());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // You can replace with proper logger
            return false;
        }
    }
}
