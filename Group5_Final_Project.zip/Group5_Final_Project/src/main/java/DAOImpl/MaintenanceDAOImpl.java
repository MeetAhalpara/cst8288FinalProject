package DAOImpl;

import DAO.MaintenanceDAO;
import TransferObject.MaintenanceDTO;
import Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MaintenanceDAOImpl implements all methods defined in the MaintenanceDAO interface.
 * 
 * This class provides CRUD operations for maintenance records and supports
 * filtered queries like:
 * - By vehicle ID
 * - By status
 * - All maintenance alerts
 * 
 * Author: Meet Ahalpara
 */
public class MaintenanceDAOImpl implements MaintenanceDAO {

    /**
     * Inserts a new maintenance record into the database.
     *
     * @param maintenance the maintenance record to insert
     * @return true if insertion is successful, false otherwise
     */
    @Override
    public boolean insertMaintenanceRecord(MaintenanceDTO maintenance) {
        String sql = "INSERT INTO maintenance (vehicle_id, maintenance_date, cost, details) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maintenance.getVehicleId());
            ps.setDate(2, maintenance.getMaintenanceDate());
            ps.setDouble(3, maintenance.getCost());
            ps.setString(4, maintenance.getDetails());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Retrieves all maintenance alerts, joined with vehicle registration numbers.
     *
     * @return list of MaintenanceDTO records
     */
    @Override
    public List<MaintenanceDTO> getMaintenanceAlerts() {
        List<MaintenanceDTO> maintenanceList = new ArrayList<>();
        String query = "SELECT maintenance_id, registration_number, maintenance_date, cost, details " +
                       "FROM maintenance " +
                       "INNER JOIN vehicles ON maintenance.vehicle_id = vehicles.vehicle_id";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MaintenanceDTO maintenance = new MaintenanceDTO();
                maintenance.setMaintenanceId(rs.getInt("maintenance_id"));
                maintenance.setVehicleRegistration(rs.getString("registration_number"));
                maintenance.setMaintenanceDate(rs.getDate("maintenance_date"));
                maintenance.setCost(rs.getDouble("cost"));
                maintenance.setDetails(rs.getString("details"));
                maintenanceList.add(maintenance);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return maintenanceList;
    }

    /**
     * Retrieves all maintenance alerts with full vehicle data.
     *
     * @return list of all MaintenanceDTO records
     */
    @Override
    public List<MaintenanceDTO> getAllMaintenanceAlerts() {
        List<MaintenanceDTO> maintenanceList = new ArrayList<>();
        String query = "SELECT * FROM maintenance " +
                       "INNER JOIN vehicles ON maintenance.vehicle_id = vehicles.vehicle_id";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MaintenanceDTO maintenance = new MaintenanceDTO();
                maintenance.setVehicleRegistration(rs.getString("registration_number"));
                maintenance.setMaintenanceDate(rs.getDate("maintenance_date"));
                maintenance.setCost(rs.getDouble("cost"));
                maintenance.setDetails(rs.getString("details"));
                maintenanceList.add(maintenance);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return maintenanceList;
    }

    /**
     * Retrieves all maintenance records for a specific vehicle.
     *
     * @param vehicleId the ID of the vehicle
     * @return list of MaintenanceDTO records for that vehicle
     */
    @Override
    public List<MaintenanceDTO> getMaintenanceByVehicle(int vehicleId) {
        List<MaintenanceDTO> maintenanceList = new ArrayList<>();
        String query = "SELECT * FROM maintenance " +
                       "INNER JOIN vehicles ON maintenance.vehicle_id = vehicles.vehicle_id " +
                       "WHERE vehicles.vehicle_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, vehicleId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MaintenanceDTO maintenance = new MaintenanceDTO();
                    maintenance.setVehicleRegistration(rs.getString("registration_number"));
                    maintenance.setMaintenanceDate(rs.getDate("maintenance_date"));
                    maintenance.setCost(rs.getDouble("cost"));
                    maintenance.setDetails(rs.getString("details"));
                    maintenanceList.add(maintenance);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return maintenanceList;
    }

    /**
     * Retrieves maintenance records filtered by status.
     *
     * @param status the maintenance status (e.g., "Pending", "Completed")
     * @return list of MaintenanceDTO records matching the status
     */
    @Override
    public List<MaintenanceDTO> getMaintenanceByStatus(String status) {
        List<MaintenanceDTO> maintenanceList = new ArrayList<>();
        String query = "SELECT * FROM maintenance " +
                       "INNER JOIN vehicles ON maintenance.vehicle_id = vehicles.vehicle_id " +
                       "WHERE maintenance.status = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, status);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MaintenanceDTO maintenance = new MaintenanceDTO();
                    maintenance.setVehicleRegistration(rs.getString("registration_number"));
                    maintenance.setMaintenanceDate(rs.getDate("maintenance_date"));
                    maintenance.setCost(rs.getDouble("cost"));
                    maintenance.setDetails(rs.getString("details"));
                    maintenanceList.add(maintenance);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return maintenanceList;
    }

    /**
     * Updates a maintenance record based on its ID.
     *
     * @param maintenance the updated maintenance data
     * @return true if update is successful, false otherwise
     */
    @Override
    public boolean updateMaintenanceRecord(MaintenanceDTO maintenance) {
        String sql = "UPDATE maintenance SET vehicle_id = ?, maintenance_date = ?, cost = ?, details = ? WHERE maintenance_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maintenance.getVehicleId());
            ps.setDate(2, maintenance.getMaintenanceDate());
            ps.setDouble(3, maintenance.getCost());
            ps.setString(4, maintenance.getDetails());
            ps.setInt(5, maintenance.getMaintenanceId());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Deletes a maintenance record from the database using its ID.
     *
     * @param maintenanceId the ID of the maintenance record
     * @return true if deletion is successful, false otherwise
     */
    @Override
    public boolean deleteMaintenanceRecord(int maintenanceId) {
        String sql = "DELETE FROM maintenance WHERE maintenance_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maintenanceId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Retrieves a maintenance record by its unique ID.
     *
     * @param maintenanceId the ID of the maintenance record
     * @return a MaintenanceDTO object if found, otherwise null
     */
    @Override
    public MaintenanceDTO getMaintenanceById(int maintenanceId) {
        String query = "SELECT m.*, v.registration_number FROM maintenance m " +
                       "JOIN vehicles v ON m.vehicle_id = v.vehicle_id " +
                       "WHERE m.maintenance_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, maintenanceId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    MaintenanceDTO maintenance = new MaintenanceDTO();
                    maintenance.setMaintenanceId(rs.getInt("maintenance_id"));
                    maintenance.setVehicleId(rs.getInt("vehicle_id"));
                    maintenance.setMaintenanceDate(rs.getDate("maintenance_date"));
                    maintenance.setCost(rs.getDouble("cost"));
                    maintenance.setDetails(rs.getString("details"));
                    maintenance.setVehicleRegistration(rs.getString("registration_number"));
                    return maintenance;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
