package DAOImpl;

import DAO.RouteDAO;
import TransferObject.RouteDTO;
import Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * RouteDAOImpl provides the implementation for managing route data in the system.
 * 
 * It handles operations such as:
 * - Adding, retrieving, updating, and deleting routes
 * - Fetching all available routes from the database
 * 
 * Author: Meet Ahalpara
 */
public class RouteDAOImpl implements RouteDAO {

    /**
     * Retrieves all available routes from the `routes` table.
     * 
     * @return a list of RouteDTO objects containing route details
     */
    @Override
    public List<RouteDTO> getAllRoutes() {
        List<RouteDTO> routes = new ArrayList<>();
        String sql = "SELECT route_id, route_name, start_location, end_location FROM routes";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                RouteDTO route = new RouteDTO();
                route.setRouteId(rs.getInt("route_id"));
                route.setRouteName(rs.getString("route_name"));
                route.setStartLocation(rs.getString("start_location"));
                route.setEndLocation(rs.getString("end_location"));
                routes.add(route);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return routes;
    }

    /**
     * Retrieves a specific route by its ID from the database.
     * 
     * @param routeId the ID of the route to retrieve
     * @return the corresponding RouteDTO if found, otherwise null
     */
    @Override
    public RouteDTO getRouteById(int routeId) {
        RouteDTO route = null;
        String sql = "SELECT * FROM routes WHERE route_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, routeId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                route = new RouteDTO();
                route.setRouteId(rs.getInt("route_id"));
                route.setRouteName(rs.getString("route_name"));
                route.setStartLocation(rs.getString("start_location"));
                route.setEndLocation(rs.getString("end_location"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return route;
    }

    /**
     * Adds a new route to the database.
     * 
     * @param route the RouteDTO containing route name, start, and end locations
     * @return true if the route is successfully added, false otherwise
     */
    @Override
    public boolean addRoute(RouteDTO route) {
        String sql = "INSERT INTO routes (route_name, start_location, end_location) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, route.getRouteName());
            ps.setString(2, route.getStartLocation());
            ps.setString(3, route.getEndLocation());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Updates an existing route in the database.
     * 
     * @param route the RouteDTO containing updated values and the route ID
     * @return true if the route is successfully updated, false otherwise
     */
    @Override
    public boolean updateRoute(RouteDTO route) {
        String sql = "UPDATE routes SET route_name = ?, start_location = ?, end_location = ? WHERE route_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, route.getRouteName());
            ps.setString(2, route.getStartLocation());
            ps.setString(3, route.getEndLocation());
            ps.setInt(4, route.getRouteId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Deletes a route from the database by its ID.
     * 
     * @param routeId the ID of the route to delete
     * @return true if the route was deleted, false otherwise
     */
    @Override
    public boolean deleteRoute(int routeId) {
        String sql = "DELETE FROM routes WHERE route_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, routeId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
