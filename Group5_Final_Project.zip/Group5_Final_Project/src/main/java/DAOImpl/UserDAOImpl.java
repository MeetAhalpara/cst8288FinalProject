package DAOImpl;

import DAO.UserDAO;
import TransferObject.UserDTO;
import Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * UserDAOImpl provides concrete implementations for user-related database operations.
 * 
 * This includes registering users, login authentication, checking usernames,
 * retrieving user lists, and managing role assignments.
 * 
 * Author: Meet Ahalpara
 */
public class UserDAOImpl implements UserDAO {

    /**
     * Registers a new user by inserting their details into the users table and assigning a role.
     *
     * @param user the UserDTO containing username, password, email, and role ID
     * @return true if registration and role assignment are successful, false otherwise
     */
    @Override
    public boolean registerUser(UserDTO user) {
        String insertUserSQL = "INSERT INTO users (username, password, email, created_at) VALUES (?, ?, ?, ?)";
        String insertUserRoleSQL = "INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement userStmt = conn.prepareStatement(insertUserSQL, Statement.RETURN_GENERATED_KEYS)) {

            userStmt.setString(1, user.getUsername().trim());
            userStmt.setString(2, user.getPassword().trim());
            userStmt.setString(3, user.getEmail().trim());
            userStmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

            int rowsInserted = userStmt.executeUpdate();
            if (rowsInserted > 0) {
                ResultSet keys = userStmt.getGeneratedKeys();
                if (keys.next()) {
                    int userId = keys.getInt(1);
                    System.out.println("Registered user ID: " + userId);

                    // Assign role
                    try (PreparedStatement roleStmt = conn.prepareStatement(insertUserRoleSQL)) {
                        roleStmt.setInt(1, userId);
                        roleStmt.setInt(2, user.getRoleId());

                        int roleInserted = roleStmt.executeUpdate();
                        if (roleInserted > 0) {
                            System.out.println(" Role assigned successfully");
                            return true;
                        } else {
                            System.out.println(" Failed to assign role");
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Authenticates a user by checking the username and password combination.
     *
     * @param username the user's username
     * @param password the user's password
     * @return a UserDTO if credentials match, otherwise null
     */
    @Override
    public UserDTO loginUser(String username, String password) {
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, username.trim());
            ps.setString(2, password.trim());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    UserDTO user = new UserDTO();
                    user.setUserId(rs.getInt("userId"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setEmail(rs.getString("email"));
                    user.setCreatedAt(rs.getTimestamp("created_at"));
                    return user;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Checks if the given username is already taken.
     *
     * @param username the username to check
     * @return true if the username exists, false otherwise
     */
    @Override
    public boolean isUsernameTaken(String username) {
        String query = "SELECT userId FROM users WHERE LOWER(TRIM(username)) = LOWER(TRIM(?))";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            String trimmedUsername = username.trim();
            ps.setString(1, trimmedUsername);

            System.out.println(" Checking if username exists: [" + trimmedUsername + "]");

            try (ResultSet rs = ps.executeQuery()) {
                boolean exists = rs.next();
                System.out.println("Username exists? " + exists);
                return exists;
            }

        } catch (Exception e) {
            System.out.println(" Error in isUsernameTaken: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Retrieves all users from the users table.
     *
     * @return a list of UserDTO containing basic user info
     */
    @Override
    public List<UserDTO> getAllUsers() {
        List<UserDTO> users = new ArrayList<>();
        String sql = "SELECT * FROM users";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                UserDTO user = new UserDTO();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                users.add(user);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return users;
    }

    /**
     * Retrieves users based on their assigned role.
     *
     * @param role the role name (e.g., "Operator", "Manager")
     * @return list of users assigned to the specified role
     */
    @Override
    public List<UserDTO> getUsersByRole(String role) {
        List<UserDTO> users = new ArrayList<>();
        String sql = "SELECT u.* FROM users u " +
                     "JOIN user_roles ur ON u.user_id = ur.user_id " +
                     "WHERE ur.role = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, role);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                UserDTO user = new UserDTO();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                users.add(user);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return users;
    }

    /**
     * Assigns a role to a user in the user_roles table.
     *
     * @param userId the user ID
     * @param role the role name to assign
     * @return true if the role was assigned successfully, false otherwise
     */
    @Override
    public boolean assignRoleToUser(int userId, String role) {
        String sql = "INSERT INTO user_roles (user_id, role) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setString(2, role);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
