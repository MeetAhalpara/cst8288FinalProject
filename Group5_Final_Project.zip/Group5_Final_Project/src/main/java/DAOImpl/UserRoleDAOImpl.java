package DAOImpl;

import DAO.UserRoleDAO;
import Utility.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * UserRoleDAOImpl provides an implementation for assigning roles to users.
 * 
 * This class updates the `users` table and sets the role name for a specific user.
 * 
 * Author: Meet Ahalpara
 */
public class UserRoleDAOImpl implements UserRoleDAO {

    /**
     * Assigns a role to a user by updating the `role` column in the `users` table.
     * 
     * @param userId the ID of the user to whom the role should be assigned
     * @param role the name of the role (e.g., "Manager", "Operator")
     */
    @Override
    public void assignRole(int userId, String role) {
        String sql = "UPDATE users SET role = ? WHERE user_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, role);
            ps.setInt(2, userId);
            ps.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
