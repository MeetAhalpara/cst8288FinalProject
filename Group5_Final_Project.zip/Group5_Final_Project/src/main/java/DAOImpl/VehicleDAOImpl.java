package DAOImpl;

import DAO.VehicleDAO;
import TransferObject.VehicleDTO;
import Utility.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * VehicleDAOImpl is the concrete implementation of VehicleDAO.
 * 
 * It manages vehicle data in the system including:
 * - CRUD operations
 * - Assigning routes
 * - Updating status
 * - Filtering based on operator ID
 * - Fuel usage and status-based analytics
 * 
 * Author: Meet Ahalpara
 */
public class VehicleDAOImpl implements VehicleDAO {

    /**
     * Returns all vehicles assigned to a specific operator by user ID.
     * 
     * userId: ID of the operator
     * return: list of VehicleDTOs assigned to the operator
     */
    @Override
    public List<VehicleDTO> getVehiclesByOperatorId(int userId) {
        List<VehicleDTO> vehicles = new ArrayList<>();
        String sql = "SELECT DISTINCT v.* " +
                     "FROM vehicles v " +
                     "JOIN assignments a ON v.vehicle_id = a.vehicle_id " +
                     "WHERE a.route_id = (SELECT route_id FROM user_roles WHERE user_id = ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                VehicleDTO v = new VehicleDTO();
                v.setVehicleId(rs.getInt("vehicle_id"));
                v.setRegistrationNumber(rs.getString("registration_number"));
                v.setModel(rs.getString("model"));
                v.setVehicleType(rs.getString("vehicle_type"));
                v.setFuelType(rs.getString("fuel_type"));
                v.setConsumptionRate(rs.getDouble("consumption_rate"));
                v.setCapacity(rs.getInt("capacity"));
                v.setStatus(rs.getString("status"));
                vehicles.add(v);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return vehicles;
    }

    /**
     * Updates the status of a vehicle.
     * 
     * vehicleId: ID of the vehicle
     * newStatus: new status to be updated
     * return: true if update was successful, false otherwise
     */
    @Override
    public boolean updateVehicleStatus(int vehicleId, String newStatus) {
        String sql = "UPDATE vehicles SET status = ? WHERE vehicle_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newStatus);
            ps.setInt(2, vehicleId);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Returns vehicle status counts grouped by status for a specific operator.
     * 
     * userId: ID of the operator
     * return: map of status to count
     */
    @Override
    public Map<String, Integer> getVehicleStatusCountsByOperator(int userId) {
        Map<String, Integer> statusCounts = new HashMap<>();
        String sql = "SELECT v.status, COUNT(*) AS count " +
                     "FROM vehicles v " +
                     "JOIN assignments a ON v.vehicle_id = a.vehicle_id " +
                     "WHERE a.route_id = (SELECT route_id FROM user_roles WHERE user_id = ?) " +
                     "GROUP BY v.status";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                statusCounts.put(rs.getString("status"), rs.getInt("count"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return statusCounts;
    }

    /**
     * Adds a new vehicle to the database.
     * 
     * vehicle: vehicle data to add
     * return: true if insertion was successful, false otherwise
     */
    @Override
    public boolean addVehicle(VehicleDTO vehicle) {
        String sql = "INSERT INTO vehicles (registration_number, model, vehicle_type, fuel_type, consumption_rate, capacity, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, vehicle.getRegistrationNumber());
            ps.setString(2, vehicle.getModel());
            ps.setString(3, vehicle.getVehicleType());
            ps.setString(4, vehicle.getFuelType());
            ps.setDouble(5, vehicle.getConsumptionRate());
            ps.setInt(6, vehicle.getCapacity());
            ps.setString(7, vehicle.getStatus());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            if (e.getMessage().contains("Duplicate entry") && e.getMessage().contains("registration_number")) {
                System.err.println("🚫 Vehicle with this registration number already exists.");
            } else {
                System.err.println("SQL Error: " + e.getMessage());
            }
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Updates an existing vehicle record.
     * 
     * vehicle: vehicle data to update
     * return: true if update was successful, false otherwise
     */
    @Override
    public boolean updateVehicle(VehicleDTO vehicle) {
        String sql = "UPDATE vehicles SET registration_number=?, model=?, vehicle_type=?, fuel_type=?, " +
                     "consumption_rate=?, capacity=?, status=? WHERE vehicle_id=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, vehicle.getRegistrationNumber());
            ps.setString(2, vehicle.getModel());
            ps.setString(3, vehicle.getVehicleType());
            ps.setString(4, vehicle.getFuelType());
            ps.setDouble(5, vehicle.getConsumptionRate());
            ps.setInt(6, vehicle.getCapacity());
            ps.setString(7, vehicle.getStatus());
            ps.setInt(8, vehicle.getVehicleId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Deletes a vehicle record by ID.
     * 
     * vehicleId: ID of the vehicle to delete
     * return: true if deletion was successful, false otherwise
     */
    @Override
    public boolean deleteVehicle(int vehicleId) {
        String sql = "DELETE FROM vehicles WHERE vehicle_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, vehicleId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Retrieves a vehicle by its ID.
     * 
     * vehicleId: ID of the vehicle
     * return: VehicleDTO object or null if not found
     */
    @Override
    public VehicleDTO getVehicleById(int vehicleId) {
        String sql = "SELECT * FROM vehicles WHERE vehicle_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, vehicleId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                VehicleDTO vehicle = new VehicleDTO();
                vehicle.setVehicleId(rs.getInt("vehicle_id"));
                vehicle.setRegistrationNumber(rs.getString("registration_number"));
                vehicle.setModel(rs.getString("model"));
                vehicle.setVehicleType(rs.getString("vehicle_type"));
                vehicle.setFuelType(rs.getString("fuel_type"));
                vehicle.setConsumptionRate(rs.getDouble("consumption_rate"));
                vehicle.setCapacity(rs.getInt("capacity"));
                vehicle.setStatus(rs.getString("status"));
                return vehicle;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Returns a list of all vehicles in the database.
     * 
     * return: list of VehicleDTO objects
     */
    @Override
    public List<VehicleDTO> getAllVehicles() {
        List<VehicleDTO> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM vehicles";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                VehicleDTO v = new VehicleDTO();
                v.setVehicleId(rs.getInt("vehicle_id"));
                v.setRegistrationNumber(rs.getString("registration_number"));
                v.setModel(rs.getString("model"));
                v.setVehicleType(rs.getString("vehicle_type"));
                v.setFuelType(rs.getString("fuel_type"));
                v.setConsumptionRate(rs.getDouble("consumption_rate"));
                v.setCapacity(rs.getInt("capacity"));
                v.setStatus(rs.getString("status"));
                vehicles.add(v);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return vehicles;
    }

    /**
     * Assigns a route to a vehicle using the vehicle_routes table.
     * 
     * vehicleId: ID of the vehicle
     * routeId: ID of the route
     * return: true if assignment was successful, false otherwise
     */
    @Override
    public boolean assignRouteToVehicle(int vehicleId, int routeId) {
        String sql = "INSERT INTO vehicle_routes (vehicle_id, route_id) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, vehicleId);
            ps.setInt(2, routeId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Assigns a route to a vehicle along with start and end dates.
     * 
     * vehicleId: ID of the vehicle
     * routeId: ID of the route
     * startDate: start date as string (yyyy-MM-dd)
     * endDate: end date as string (nullable)
     * return: true if assignment was successful, false otherwise
     */
    @Override
    public boolean assignRouteToVehicle(int vehicleId, int routeId, String startDate, String endDate) {
        String sql = "INSERT INTO assignments (vehicle_id, route_id, start_date, end_date) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, vehicleId);
            ps.setInt(2, routeId);
            ps.setDate(3, java.sql.Date.valueOf(startDate));

            if (endDate == null || endDate.trim().isEmpty()) {
                ps.setNull(4, java.sql.Types.DATE);
            } else {
                ps.setDate(4, java.sql.Date.valueOf(endDate));
            }

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
