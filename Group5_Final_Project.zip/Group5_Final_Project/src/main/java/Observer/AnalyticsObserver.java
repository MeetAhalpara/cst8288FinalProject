package Observer;

import TransferObject.VehicleDTO;

/**
 * AnalyticsObserver is an implementation of the Observer interface.
 * 
 * It listens for changes to vehicle status and logs an analytics-related message
 * when a vehicle's status is updated.
 * 
 * Author: Meet Ahalpara
 */
public class AnalyticsObserver implements Observer {

    /**
     * Triggered when the observed vehicle changes.
     * 
     * vehicle: the VehicleDTO object whose status has changed
     */
    @Override
    public void update(VehicleDTO vehicle) {
        System.out.println("[AnalyticsObserver] Vehicle " + vehicle.getRegistrationNumber() +
                           " changed status to " + vehicle.getStatus());
    }
}
