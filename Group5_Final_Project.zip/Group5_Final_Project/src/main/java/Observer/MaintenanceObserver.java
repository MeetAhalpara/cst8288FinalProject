package Observer;

import TransferObject.VehicleDTO;

/**
 * MaintenanceObserver is an implementation of the Observer interface.
 * 
 * It reacts when a vehicle's status changes. If the status becomes "Under Maintenance",
 * it logs a message indicating that the vehicle is under maintenance.
 * 
 * Author: Meet Ahalpara
 */
public class MaintenanceObserver implements Observer {

    /**
     * Called when the observed vehicle changes.
     * 
     * vehicle: the VehicleDTO object being observed
     */
    @Override
    public void update(VehicleDTO vehicle) {
        if ("Under Maintenance".equalsIgnoreCase(vehicle.getStatus())) {
            System.out.println("[MaintenanceObserver] Vehicle " + vehicle.getRegistrationNumber() +
                               " is now UNDER MAINTENANCE.");
        }
    }
}
