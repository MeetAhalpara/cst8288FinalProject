package Observer;

import TransferObject.VehicleDTO;

/**
 * Observer interface for the Observer design pattern.
 * 
 * Implementing classes will respond to changes in the state of a VehicleDTO object,
 * such as status updates.
 * 
 * Author: Meet Ahalpara
 */
public interface Observer {

    /**
     * Method called when the observed vehicle is updated.
     * 
     * vehicle: the VehicleDTO object whose state has changed
     */
    void update(VehicleDTO vehicle);
}
