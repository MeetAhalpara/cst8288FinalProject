package Observer;

import TransferObject.VehicleDTO;
import java.util.ArrayList;
import java.util.List;

/**
 * VehicleStatusNotifier implements the VehicleStatusSubject interface.
 * 
 * It maintains a list of observers and notifies them whenever a vehicle's
 * status is updated.
 * 
 * Author: Meet Ahalpara
 */
public class VehicleStatusNotifier implements VehicleStatusSubject {

    private final List<Observer> observers = new ArrayList<>();

    /**
     * Adds an observer to the list.
     * 
     * observer: the Observer that wants to receive updates
     */
    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    /**
     * Removes an observer from the list.
     * 
     * observer: the Observer to remove
     */
    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    /**
     * Notifies all registered observers about a vehicle update.
     * 
     * vehicle: the VehicleDTO that has changed
     */
    @Override
    public void notifyObservers(VehicleDTO vehicle) {
        for (Observer obs : observers) {
            obs.update(vehicle);
        }
    }
}
