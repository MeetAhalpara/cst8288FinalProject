package Observer;

import TransferObject.VehicleDTO;

/**
 *
 * @author Meet Ahalpara
 */
public interface VehicleStatusSubject {

    /**
     *
     * @param observer
     */
    void addObserver(Observer observer);

    /**
     *
     * @param observer
     */
    void removeObserver(Observer observer);

    /**
     *
     * @param vehicle
     */
    void notifyObservers(VehicleDTO vehicle);
}
