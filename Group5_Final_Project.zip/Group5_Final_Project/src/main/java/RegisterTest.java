import Utility.DatabaseConnection;
import java.sql.*;

/**
 * RegisterTest is a simple Java test class used to insert a user directly
 * into the database and assign a role to them.
 * 
 * It performs two actions:
 * 1. Inserts a new record into the users table.
 * 2. Inserts a corresponding role into the user_roles table using the generated user ID.
 * 
 * This class is useful for testing the database setup and user-role assignments.
 * 
 * Author: icyop
 */
public class RegisterTest {

    /**
     * The main method executes the user registration test.
     * 
     * It connects to the database, inserts a user, retrieves the generated user ID,
     * and then assigns a role to the user. If successful, it prints confirmation
     * messages to the console.
     */
    public static void main(String[] args) {
        String username = "george_patel";
        String password = "111";
        String email = "george@ptfms.com";
        int roleId = 2; // 1 = Admin, 2 = Operator, 3 = Manager

        try (Connection conn = DatabaseConnection.getConnection()) {

            // Insert new user
            String insertUserSQL = "INSERT INTO users (username, password, email, created_at) VALUES (?, ?, ?, ?)";
            PreparedStatement userStmt = conn.prepareStatement(insertUserSQL, Statement.RETURN_GENERATED_KEYS);

            userStmt.setString(1, username.trim());
            userStmt.setString(2, password.trim());
            userStmt.setString(3, email.trim());
            userStmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

            int rowsInserted = userStmt.executeUpdate();
            if (rowsInserted > 0) {
                ResultSet keys = userStmt.getGeneratedKeys();
                if (keys.next()) {
                    int userId = keys.getInt(1);
                    System.out.println(" User registered with ID: " + userId);

                    // Assign role to the user
                    String insertRoleSQL = "INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)";
                    PreparedStatement roleStmt = conn.prepareStatement(insertRoleSQL);
                    roleStmt.setInt(1, userId);
                    roleStmt.setInt(2, roleId);

                    int roleInserted = roleStmt.executeUpdate();
                    if (roleInserted > 0) {
                        System.out.println("Role assigned successfully (Role ID: " + roleId + ")");
                    } else {
                        System.out.println(" Failed to assign role.");
                    }
                    roleStmt.close();
                }
                keys.close();
            } else {
                System.out.println(" User registration failed.");
            }

            userStmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
