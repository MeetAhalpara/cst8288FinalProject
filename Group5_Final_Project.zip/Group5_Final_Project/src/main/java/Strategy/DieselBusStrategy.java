package Strategy;

import TransferObject.VehicleDTO;

/**
 * Strategy implementation for Diesel Bus fuel consumption analysis.
 * 
 * This strategy considers a Diesel Bus to be consuming excessively if 
 * its consumption rate exceeds 10.0 units.
 * 
 * Author: Meet Ahalpara
 */
public class DieselBusStrategy implements FuelConsumptionStrategy {

    /**
     * Checks if the vehicle's fuel consumption exceeds the acceptable threshold.
     * 
     * @param vehicle the VehicleDTO representing the Diesel Bus
     * @return true if the consumption rate is above 10.0, false otherwise
     */
    @Override
    public boolean isExcessive(VehicleDTO vehicle) {
        return vehicle.getConsumptionRate() > 10.0;
    }
}
