package Strategy;

import TransferObject.VehicleDTO;

/**
 * Strategy implementation for Diesel-Electric Train fuel consumption analysis.
 * 
 * This strategy flags a train as having excessive consumption if its 
 * rate exceeds 15.0 units.
 * 
 * Author: Meet Ahalpara
 */
public class DieselElectricTrainStrategy implements FuelConsumptionStrategy {

    /**
     * Determines whether the train's fuel consumption is excessive.
     *
     * @param vehicle the VehicleDTO representing the Diesel-Electric Train
     * @return true if consumption rate exceeds 15.0, false otherwise
     */
    @Override
    public boolean isExcessive(VehicleDTO vehicle) {
        return vehicle.getConsumptionRate() > 15.0;
    }
}
