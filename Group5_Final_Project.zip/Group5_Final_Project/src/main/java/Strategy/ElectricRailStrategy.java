package Strategy;

import TransferObject.VehicleDTO;

/**
 * Strategy implementation for Electric Light Rail fuel consumption analysis.
 * 
 * Flags a vehicle as having excessive consumption if the rate exceeds 5.0 units.
 * 
 * Author: Meet Ahalpara
 */
public class ElectricRailStrategy implements FuelConsumptionStrategy {

    /**
     * Determines whether the electric rail's energy usage is excessive.
     *
     * @param vehicle the VehicleDTO representing the Electric Light Rail
     * @return true if consumption rate exceeds 5.0, false otherwise
     */
    @Override
    public boolean isExcessive(VehicleDTO vehicle) {
        return vehicle.getConsumptionRate() > 5.0;
    }
}
