package Strategy;

import TransferObject.VehicleDTO;

/**
 * Context class for applying fuel consumption strategy dynamically.
 * 
 * Holds a reference to a FuelConsumptionStrategy and delegates 
 * the consumption check to it.
 * 
 * Author: Meet Ahalpara
 */
public class FuelConsumptionContext {
    
    private FuelConsumptionStrategy strategy;

    /**
     * Sets the fuel consumption strategy to be used.
     *
     * @param strategy the FuelConsumptionStrategy implementation
     */
    public void setStrategy(FuelConsumptionStrategy strategy) {
        this.strategy = strategy;
    }

    /**
     * Applies the current strategy to check if a vehicle's consumption is excessive.
     *
     * @param vehicle the VehicleDTO to check
     * @return true if consumption is excessive, false otherwise
     */
    public boolean checkExcessive(VehicleDTO vehicle) {
        return strategy.isExcessive(vehicle);
    }
}
