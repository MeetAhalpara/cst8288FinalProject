package Strategy;

import TransferObject.VehicleDTO;

/**
 *
 * @author Meet Ahalpara
 */
public interface FuelConsumptionStrategy {

    /**
     *
     * @param vehicle
     * @return
     */
    boolean isExcessive(VehicleDTO vehicle);
}
