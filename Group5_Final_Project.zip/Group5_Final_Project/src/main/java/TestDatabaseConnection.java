import java.sql.Connection;
import Utility.DatabaseConnection;

/**
 * TestDatabaseConnection is a simple Java utility class used to test whether
 * the database connection is working properly.
 * 
 * It attempts to connect using the DatabaseConnection utility and prints
 * a success or failure message to the console.
 * 
 * Author: Meet Ahalpara and Samarth Patel
 */
public class TestDatabaseConnection {

    /**
     * The main method tests the database connection.
     * 
     * If the connection is successful, it prints a success message and closes the connection.
     * If the connection fails or an exception occurs, it prints an error message.
     */
    public static void main(String[] args) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                System.out.println(" Database connection successful!");
                conn.close();
            } else {
                System.out.println(" Database connection failed.");
            }
        } catch (Exception e) {
            System.out.println(" Exception occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
