import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * TestServlet is a basic servlet used to confirm that servlet
 * deployment and configuration are working correctly.
 * 
 * When accessed via a GET request, it prints a simple success message.
 * 
 * Author: Meet Ahalpara 
 */
@WebServlet("/test")
public class TestServlet extends HttpServlet {

    /**
     * Handles GET requests and responds with a simple confirmation message.
     * 
     * This can be used to check if the servlet is working and reachable.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.getWriter().println("Servlet works!");
    }
}
