package TransferObject;

import java.sql.Date;

/**
 * AssignmentDTO is a Data Transfer Object that represents the assignment of a vehicle to a route.
 * 
 * It contains information such as:
 * - vehicle ID
 * - route ID and name
 * - start and end dates of the assignment
 * - vehicle registration number
 * 
 * Author: Mohammadsaffan Vahora
 */
public class AssignmentDTO {

    private int vehicleId;
    private String routeName;
    private int routeId;
    private Date startDate;
    private Date endDate;
    private String vehicleRegistrationNumber;

    /**
     * Gets the ID of the assigned vehicle.
     * 
     * @return vehicleId
     */
    public int getVehicleId() {
        return vehicleId;
    }

    /**
     * Sets the ID of the assigned vehicle.
     * 
     * @param vehicleId the vehicle ID to set
     */
    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    /**
     * Gets the name of the route.
     * 
     * @return routeName
     */
    public String getRouteName() {
        return routeName;
    }

    /**
     * Sets the name of the route.
     * 
     * @param routeName the name of the route to set
     */
    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    /**
     * Gets the ID of the route.
     * 
     * @return routeId
     */
    public int getRouteId() {
        return routeId;
    }

    /**
     * Sets the ID of the route.
     * 
     * @param routeId the route ID to set
     */
    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    /**
     * Gets the start date of the assignment.
     * 
     * @return startDate
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * Sets the start date of the assignment.
     * 
     * @param startDate the start date to set
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * Gets the end date of the assignment.
     * 
     * @return endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * Sets the end date of the assignment.
     * 
     * @param endDate the end date to set
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * Gets the vehicle's registration number.
     * 
     * @return vehicleRegistrationNumber
     */
    public String getVehicleRegistrationNumber() {
        return vehicleRegistrationNumber;
    }

    /**
     * Sets the vehicle's registration number.
     * 
     * @param vehicleRegistrationNumber the registration number to set
     */
    public void setVehicleRegistrationNumber(String vehicleRegistrationNumber) {
        this.vehicleRegistrationNumber = vehicleRegistrationNumber;
    }
}
