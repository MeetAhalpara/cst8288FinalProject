package TransferObject;

import java.sql.Timestamp;

/**
 *
 * @author Mohammadsaffan Vahora
 */
public class GpsTrackingDTO {
    private int gpsId;
    private int vehicleId;
    private int routeId;
    private double latitude;
    private double longitude;
    private Timestamp timestamp;

    // Default constructor

    /**
     *
     */
    public GpsTrackingDTO() {}

    // Constructor with parameters

    /**
     *
     * @param gpsId
     * @param vehicleId
     * @param routeId
     * @param latitude
     * @param longitude
     * @param timestamp
     */
    public GpsTrackingDTO(int gpsId, int vehicleId, int routeId, double latitude, double longitude, Timestamp timestamp) {
        this.gpsId = gpsId;
        this.vehicleId = vehicleId;
        this.routeId = routeId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.timestamp = timestamp;
    }

    // Getters and Setters

    /**
     *
     * @return
     */
    public int getGpsId() {
        return gpsId;
    }

    /**
     *
     * @param gpsId
     */
    public void setGpsId(int gpsId) {
        this.gpsId = gpsId;
    }

    /**
     *
     * @return
     */
    public int getVehicleId() {
        return vehicleId;
    }

    /**
     *
     * @param vehicleId
     */
    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    /**
     *
     * @return
     */
    public int getRouteId() {
        return routeId;
    }

    /**
     *
     * @param routeId
     */
    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    /**
     *
     * @return
     */
    public double getLatitude() {
        return latitude;
    }

    /**
     *
     * @param latitude
     */
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    /**
     *
     * @return
     */
    public double getLongitude() {
        return longitude;
    }

    /**
     *
     * @param longitude
     */
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    /**
     *
     * @return
     */
    public Timestamp getTimestamp() {
        return timestamp;
    }

    /**
     *
     * @param timestamp
     */
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "GpsTrackingDTO [gpsId=" + gpsId + ", vehicleId=" + vehicleId + ", routeId=" + routeId + 
               ", latitude=" + latitude + ", longitude=" + longitude + ", timestamp=" + timestamp + "]";
    }
}

