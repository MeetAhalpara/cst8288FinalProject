package TransferObject;

/**
 * LoginCredentialsDTO is a Data Transfer Object used for user authentication.
 * 
 * It encapsulates:
 * - username
 * - password
 * 
 * Author: Mohammadsaffan Vahora
 */
public class LoginCredentialsDTO {

    private String username;
    private String password;

    /**
     * Default constructor.
     */
    public LoginCredentialsDTO() {}

    /**
     * Parameterized constructor to initialize login credentials.
     * 
     * @param username the username for login
     * @param password the password for login
     */
    public LoginCredentialsDTO(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * Gets the username.
     * 
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username.
     * 
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the password.
     * 
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password.
     * 
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
