package TransferObject;

import java.sql.Date;

/**
 * MaintenanceDTO is a Data Transfer Object used to represent maintenance
 * records for vehicles in the Public Transit Fleet Management System.
 * 
 * It contains:
 * - maintenance ID
 * - vehicle ID
 * - maintenance date
 * - cost
 * - details/description
 * - vehicle registration number (for display purposes)
 * 
 * Author: Mohammadsaffan Vahora
 */
public class MaintenanceDTO {

    private int maintenanceId;
    private int vehicleId;
    private Date maintenanceDate;
    private double cost;
    private String details;
    private String vehicleRegistration;

    /**
     * Default constructor.
     */
    public MaintenanceDTO() {}

    /**
     * Parameterized constructor for quick initialization.
     * 
     * @param maintenanceId the maintenance record ID
     * @param vehicleId the ID of the vehicle maintained
     * @param maintenanceDate the date of maintenance
     * @param cost the cost of maintenance
     * @param details description or reason for maintenance
     */
    public MaintenanceDTO(int maintenanceId, int vehicleId, Date maintenanceDate, double cost, String details) {
        this.maintenanceId = maintenanceId;
        this.vehicleId = vehicleId;
        this.maintenanceDate = maintenanceDate;
        this.cost = cost;
        this.details = details;
    }

    /**
     * Gets the maintenance ID.
     * 
     * @return maintenance ID
     */
    public int getMaintenanceId() {
        return maintenanceId;
    }

    /**
     * Sets the maintenance ID.
     * 
     * @param maintenanceId the maintenance ID
     */
    public void setMaintenanceId(int maintenanceId) {
        this.maintenanceId = maintenanceId;
    }

    /**
     * Gets the vehicle ID associated with this maintenance.
     * 
     * @return vehicle ID
     */
    public int getVehicleId() {
        return vehicleId;
    }

    /**
     * Sets the vehicle ID.
     * 
     * @param vehicleId the vehicle ID
     */
    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    /**
     * Gets the date of maintenance.
     * 
     * @return maintenance date
     */
    public Date getMaintenanceDate() {
        return maintenanceDate;
    }

    /**
     * Sets the date of maintenance.
     * 
     * @param maintenanceDate the date of maintenance
     */
    public void setMaintenanceDate(Date maintenanceDate) {
        this.maintenanceDate = maintenanceDate;
    }

    /**
     * Gets the maintenance cost.
     * 
     * @return cost
     */
    public double getCost() {
        return cost;
    }

    /**
     * Sets the maintenance cost.
     * 
     * @param cost the cost of maintenance
     */
    public void setCost(double cost) {
        this.cost = cost;
    }

    /**
     * Gets the maintenance details or description.
     * 
     * @return details
     */
    public String getDetails() {
        return details;
    }

    /**
     * Sets the maintenance details or description.
     * 
     * @param details description of maintenance
     */
    public void setDetails(String details) {
        this.details = details;
    }

    /**
     * Gets the vehicle registration number.
     * 
     * @return vehicle registration number
     */
    public String getVehicleRegistration() {
        return vehicleRegistration;
    }

    /**
     * Sets the vehicle registration number.
     * 
     * @param vehicleRegistration the registration number of the vehicle
     */
    public void setVehicleRegistration(String vehicleRegistration) {
        this.vehicleRegistration = vehicleRegistration;
    }

    /**
     * Provides a readable representation of the MaintenanceDTO object.
     * 
     * @return a string representation of the DTO
     */
    @Override
    public String toString() {
        return "MaintenanceDTO [maintenanceId=" + maintenanceId + ", vehicleId=" + vehicleId +
               ", maintenanceDate=" + maintenanceDate + ", cost=" + cost + ", details=" + details + "]";
    }
}
