package TransferObject;

import java.sql.Timestamp;

/**
 *
 * @author Mohammadsaffan Vahora
 */
public class ReportsDTO {
    private int reportId;
    private String reportTitle;
    private String reportData;  // Storing as String to represent JSON data
    private Timestamp generatedAt;

    // Default constructor

    /**
     *
     */
    public ReportsDTO() {}

    // Constructor with parameters

    /**
     *
     * @param reportId
     * @param reportTitle
     * @param reportData
     * @param generatedAt
     */
    public ReportsDTO(int reportId, String reportTitle, String reportData, Timestamp generatedAt) {
        this.reportId = reportId;
        this.reportTitle = reportTitle;
        this.reportData = reportData;
        this.generatedAt = generatedAt;
    }

    // Getters and Setters

    /**
     *
     * @return
     */
    public int getReportId() {
        return reportId;
    }

    /**
     *
     * @param reportId
     */
    public void setReportId(int reportId) {
        this.reportId = reportId;
    }

    /**
     *
     * @return
     */
    public String getReportTitle() {
        return reportTitle;
    }

    /**
     *
     * @param reportTitle
     */
    public void setReportTitle(String reportTitle) {
        this.reportTitle = reportTitle;
    }

    /**
     *
     * @return
     */
    public String getReportData() {
        return reportData;
    }

    /**
     *
     * @param reportData
     */
    public void setReportData(String reportData) {
        this.reportData = reportData;
    }

    /**
     *
     * @return
     */
    public Timestamp getGeneratedAt() {
        return generatedAt;
    }

    /**
     *
     * @param generatedAt
     */
    public void setGeneratedAt(Timestamp generatedAt) {
        this.generatedAt = generatedAt;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "ReportsDTO [reportId=" + reportId + ", reportTitle=" + reportTitle + ", reportData=" + reportData + ", generatedAt=" + generatedAt + "]";
    }
}
