package TransferObject;

/**
 * RoleDTO is a Data Transfer Object that represents user roles in the system.
 * 
 * It encapsulates:
 * - A unique role ID
 * - A human-readable role name (e.g., Admin, Manager, Operator)
 * 
 * Author: Mohammadsaffan Vahora
 */
public class RoleDTO {

    private int roleId;
    private String roleName;

    /**
     * Default constructor.
     */
    public RoleDTO() {}

    /**
     * Constructor with parameters.
     * 
     * @param roleId the unique identifier of the role
     * @param roleName the name of the role (e.g., "Admin", "Operator")
     */
    public RoleDTO(int roleId, String roleName) {
        this.roleId = roleId;
        this.roleName = roleName;
    }

    /**
     * Gets the role ID.
     * 
     * @return the role ID
     */
    public int getRoleId() {
        return roleId;
    }

    /**
     * Sets the role ID.
     * 
     * @param roleId the role ID to set
     */
    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    /**
     * Gets the role name.
     * 
     * @return the role name
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * Sets the role name.
     * 
     * @param roleName the name of the role
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    /**
     * Returns a string representation of the role.
     * 
     * @return a string with roleId and roleName
     */
    @Override
    public String toString() {
        return "RoleDTO [roleId=" + roleId + ", roleName=" + roleName + "]";
    }
}
