package TransferObject;

/**
 * RouteDTO is a Data Transfer Object representing a transit route.
 * 
 * It encapsulates the basic information required for a route:
 * - Unique route ID
 * - Route name
 * - Start and end locations
 * 
 * Author: Mohammadsaffan Vahora
 */
public class RouteDTO {
    private int routeId;
    private String routeName;
    private String startLocation;
    private String endLocation;

    /**
     * Default constructor.
     */
    public RouteDTO() {}

    /**
     * Constructor with parameters.
     *
     * @param routeId the unique identifier for the route
     * @param routeName the name of the route (e.g., "Line A")
     * @param startLocation the start point of the route
     * @param endLocation the end point of the route
     */
    public RouteDTO(int routeId, String routeName, String startLocation, String endLocation) {
        this.routeId = routeId;
        this.routeName = routeName;
        this.startLocation = startLocation;
        this.endLocation = endLocation;
    }

    /**
     * Gets the route ID.
     *
     * @return the route ID
     */
    public int getRouteId() {
        return routeId;
    }

    /**
     * Sets the route ID.
     *
     * @param routeId the route ID to set
     */
    public void setRouteId(int routeId) {
        this.routeId = routeId;
    }

    /**
     * Gets the route name.
     *
     * @return the route name
     */
    public String getRouteName() {
        return routeName;
    }

    /**
     * Sets the route name.
     *
     * @param routeName the route name to set
     */
    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    /**
     * Gets the start location.
     *
     * @return the start location of the route
     */
    public String getStartLocation() {
        return startLocation;
    }

    /**
     * Sets the start location.
     *
     * @param startLocation the start location to set
     */
    public void setStartLocation(String startLocation) {
        this.startLocation = startLocation;
    }

    /**
     * Gets the end location.
     *
     * @return the end location of the route
     */
    public String getEndLocation() {
        return endLocation;
    }

    /**
     * Sets the end location.
     *
     * @param endLocation the end location to set
     */
    public void setEndLocation(String endLocation) {
        this.endLocation = endLocation;
    }

    /**
     * Returns a string representation of the route.
     *
     * @return a string describing the route
     */
    @Override
    public String toString() {
        return "RouteDTO [routeId=" + routeId +
               ", routeName=" + routeName +
               ", startLocation=" + startLocation +
               ", endLocation=" + endLocation + "]";
    }
}
