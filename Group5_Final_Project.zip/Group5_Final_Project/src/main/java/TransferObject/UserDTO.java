package TransferObject;

import java.sql.Timestamp;

/**
 * UserDTO represents a Data Transfer Object for user-related information.
 * It encapsulates user credentials, role, and account metadata.
 * 
 * Author: Mohammadsaffan Vahora
 */
public class UserDTO {
    private int userId;
    private String username;
    private String password;
    private String email;
    private Timestamp createdAt;
    private int roleId;

    /**
     * Default constructor.
     */
    public UserDTO() {}

    /**
     * Parameterized constructor for initializing user data.
     *
     * @param userId     the user's unique ID
     * @param username   the username
     * @param password   the password
     * @param email      the email address
     * @param createdAt  the timestamp when the user was created
     */
    public UserDTO(int userId, String username, String password, String email, Timestamp createdAt) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.email = email;
        this.createdAt = createdAt;
    }

    /** @return the user ID */
    public int getUserId() {
        return userId;
    }

    /** @param userId the user ID to set */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /** @return the username */
    public String getUsername() {
        return username;
    }

    /** @param username the username to set */
    public void setUsername(String username) {
        this.username = username;
    }

    /** @return the password */
    public String getPassword() {
        return password;
    }

    /** @param password the password to set */
    public void setPassword(String password) {
        this.password = password;
    }

    /** @return the email address */
    public String getEmail() {
        return email;
    }

    /** @param email the email address to set */
    public void setEmail(String email) {
        this.email = email;
    }

    /** @return the account creation timestamp */
    public Timestamp getCreatedAt() {
        return createdAt;
    }

    /** @param createdAt the account creation timestamp to set */
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    /** @return the role ID associated with the user */
    public int getRoleId() {
        return roleId;
    }

    /** @param roleId the role ID to set */
    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    /**
     * Provides a string representation of the user object.
     *
     * @return a string describing the user (excluding password for security)
     */
    @Override
    public String toString() {
        return "UserDTO [userId=" + userId +
               ", username=" + username +
               ", email=" + email +
               ", createdAt=" + createdAt + "]";
    }
}
