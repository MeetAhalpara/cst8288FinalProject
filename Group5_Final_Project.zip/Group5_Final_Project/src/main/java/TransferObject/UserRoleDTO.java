package TransferObject;

/**
 * UserRoleDTO represents the mapping between a user and a role.
 * It models the many-to-one relationship via userRoleId, userId, and roleId.
 * 
 * Author: Mohammadsaffan Vahora

 */
public class UserRoleDTO {
    private int userRoleId;
    private int userId;
    private int roleId;

    /**
     * Default constructor.
     */
    public UserRoleDTO() {}

    /**
     * Parameterized constructor.
     *
     * @param userRoleId the unique ID for the user-role mapping
     * @param userId     the ID of the user
     * @param roleId     the ID of the role
     */
    public UserRoleDTO(int userRoleId, int userId, int roleId) {
        this.userRoleId = userRoleId;
        this.userId = userId;
        this.roleId = roleId;
    }

    /** @return the userRoleId */
    public int getUserRoleId() {
        return userRoleId;
    }

    /** @param userRoleId the userRoleId to set */
    public void setUserRoleId(int userRoleId) {
        this.userRoleId = userRoleId;
    }

    /** @return the userId */
    public int getUserId() {
        return userId;
    }

    /** @param userId the userId to set */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /** @return the roleId */
    public int getRoleId() {
        return roleId;
    }

    /** @param roleId the roleId to set */
    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    /**
     * Provides a string representation of the user-role mapping.
     * 
     * @return a formatted string with userRoleId, userId, and roleId
     */
    @Override
    public String toString() {
        return "UserRoleDTO [userRoleId=" + userRoleId + ", userId=" + userId + ", roleId=" + roleId + "]";
    }
}
