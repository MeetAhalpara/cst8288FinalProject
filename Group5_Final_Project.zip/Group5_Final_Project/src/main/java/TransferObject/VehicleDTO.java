package TransferObject;

/**
 * VehicleDTO is a Data Transfer Object that encapsulates information
 * related to a public transit vehicle.
 * 
 * Author: Mohammadsaffan Vahora

 */
public class VehicleDTO {

    private int vehicleId;
    private String registrationNumber;
    private String model;
    private String vehicleType;
    private String fuelType;
    private double consumptionRate;
    private int capacity;
    private String status;

    /** Default constructor */
    public VehicleDTO() {}

    /**
     * Parameterized constructor to initialize a full vehicle record.
     *
     * @param vehicleId         the vehicle's unique identifier
     * @param registrationNumber the registration/license plate number
     * @param model             the model of the vehicle
     * @param vehicleType       the type (e.g., Diesel Bus, Electric Light Rail)
     * @param fuelType          the fuel type (e.g., Diesel, Electric)
     * @param consumptionRate   the fuel/energy consumption rate
     * @param capacity          the passenger or load capacity
     * @param status            the current operational status
     */
    public VehicleDTO(int vehicleId, String registrationNumber, String model, String vehicleType,
                      String fuelType, double consumptionRate, int capacity, String status) {
        this.vehicleId = vehicleId;
        this.registrationNumber = registrationNumber;
        this.model = model;
        this.vehicleType = vehicleType;
        this.fuelType = fuelType;
        this.consumptionRate = consumptionRate;
        this.capacity = capacity;
        this.status = status;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public double getConsumptionRate() {
        return consumptionRate;
    }

    public void setConsumptionRate(double consumptionRate) {
        this.consumptionRate = consumptionRate;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Returns a string representation of the vehicle object.
     *
     * @return a detailed vehicle description
     */
    @Override
    public String toString() {
        return "VehicleDTO [vehicleId=" + vehicleId +
               ", registrationNumber=" + registrationNumber +
               ", model=" + model +
               ", vehicleType=" + vehicleType +
               ", fuelType=" + fuelType +
               ", consumptionRate=" + consumptionRate +
               ", capacity=" + capacity +
               ", status=" + status + "]";
    }
}
