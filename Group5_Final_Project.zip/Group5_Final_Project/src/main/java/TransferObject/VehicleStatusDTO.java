package TransferObject;

import java.sql.Timestamp;

/**
 * VehicleStatusDTO is a Data Transfer Object that represents 
 * the status of a vehicle at a specific point in time.
 * 
 * Author: Mohammadsaffan Vahora

 */
public class VehicleStatusDTO {
    private int statusId;
    private int vehicleId;
    private String status;
    private Timestamp timestamp;

    /** Default constructor */
    public VehicleStatusDTO() {}

    /**
     * Parameterized constructor for initializing a status record.
     *
     * @param statusId  the ID of the status record
     * @param vehicleId the ID of the associated vehicle
     * @param status    the status description (e.g., Available, Under Maintenance)
     * @param timestamp the time when the status was recorded
     */
    public VehicleStatusDTO(int statusId, int vehicleId, String status, Timestamp timestamp) {
        this.statusId = statusId;
        this.vehicleId = vehicleId;
        this.status = status;
        this.timestamp = timestamp;
    }

    public int getStatusId() {
        return statusId;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Provides a readable string representation of the status entry.
     *
     * @return details of the vehicle status record
     */
    @Override
    public String toString() {
        return "VehicleStatusDTO [statusId=" + statusId +
               ", vehicleId=" + vehicleId +
               ", status=" + status +
               ", timestamp=" + timestamp + "]";
    }
}
